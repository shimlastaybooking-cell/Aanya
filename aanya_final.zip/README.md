# Aanya - Personal Phone Companion & Assistant (Moto G85)

**Aanya** is an empathetic, playful, and protective personal phone companion for Android (optimized for Motorola Moto G85 5G). She features an expressive Compose Canvas animated avatar, natural Roman Hinglish conversational abilities, push-to-talk voice interaction with lip sync, and autonomous phone task execution with strict non-bypassable safety rules.

---

## 🌟 Key Features

### 1. Animated Canvas Avatar
- **Compose Canvas Avatar**: Custom animated anime girl avatar drawn purely with Jetpack Compose Canvas.
- **Micro-Animations**:
  - Natural breathing cycle (sine wave vertical offset & scale).
  - Periodic double-blinking eye animations.
  - Smooth mouth lip-flap synchronized with TextToSpeech (`UtteranceProgressListener`).
  - Headset with pulsing cyan (`#00F0FF`) and purple (`#A855F7`) neon LED lights.
- **Dynamic Mood States**: Neutral, Happy (smiling eyes `^_^`), Sad (concerned soft eyebrows), and Caring (warm blush).
- **Dark Futuristic Aesthetic**: Tailored for the Moto G85's 120Hz 3D curved pOLED display.

### 2. Personality & Identity Boundaries
- **Roman Hinglish Dialogue**: Warm, caring tone using conversational Indian texting Hinglish (*"Arey suno na!", "Kaise ho yaar?", "Paani piya aaj?"*).
- **Empathy & Wellness Focus**: Regular check-ins for stress, sleep hygiene, hydration, and emotional well-being.
- **Strict Identity Guardrails**:
  - **No Physical Body**: Never claims to possess a physical human body (*"Main ek AI companion hoon, tumhari virtual dost!"*).
  - **AI Honesty**: Always answers truthfully when asked if she is an AI.
  - **Human Connections**: Actively encourages spending time with real family and friends.
  - **Zero Sexual Content**: Strict filtering of inappropriate or explicit messages.
  - **Crisis Helpline**: Immediate compassionate intervention for distress keywords, providing direct dial shortcuts to **Tele-MANAS (14416)** and **National Emergency (112)**.
- **Hybrid Intelligence**: Anthropic Messages API (`claude-3-5-sonnet-20241022`) with an intelligent local offline fallback engine in Hinglish.

### 3. Voice Interaction
- **SpeechRecognizer Push-to-Talk**: Hold or tap to speak in English / Hindi.
- **Visible Conversation Mode**: Dedicated toggle with a persistent, pulsing neon mic banner (mic status is never hidden).
- **Cheerful High-Pitch TTS**: Configured at 1.25f pitch with female voice selection (`en-IN` / `hi-IN`).

### 4. Autonomous Phone Task Automation
- **Semantic UI Navigation**: Powered by `AanyaAccessibilityService` & `UiNavigator`—finds buttons by text, description, or view ID (no fragile coordinate clicks).
- **Safe 12-Step Loop**:
  1. Inspects active window nodes.
  2. Asks Anthropic LLM (or local planner) for **ONE** next action in JSON.
  3. Executes (click, type, scroll, back, home).
  4. Verifies UI transition and repeats up to a maximum of 12 steps.
- **Foreground Service**: Runs with a persistent notification and a **STOP ALL** action.
- **Always-Visible Red STOP ALL Button**: Instantly halts all speech, voice recording, foreground services, and automation tasks.

### 5. Strict Safety Architecture
- **Financial & Payment Blocklist**:
  - Google Pay, PhonePe, Paytm, BHIM, YONO, HDFC, ICICI, Axis, Kotak, CRED.
  - Zerodha Kite, Groww, Binance, CoinDCX, WazirX.
  - Android Settings, Play Store, Bitwarden, 1Password, Authenticators.
- **Real-Time Sensitive Screen Blocker**: Automatically aborts if any UI node displays PIN, OTP, MPIN, CVV, or password inputs.
- **Money Intent Refusal**: Refuses any instructions related to money transfer or payments.
- **Confirmation Dialog**: Requires explicit user approval dialog before performing sensitive actions (*send, post, delete, publish*).
- **Full Audit Logging**: Transparent history of all actions and safety interventions in the Security tab.

### 6. Content Studio & Moto Utilities
- **Instagram Reels Generator**: Viral hooks, captions, and hashtags in Hinglish with Instagram share intent.
- **MediaStore 9:16 Video Filter**: Queries gallery for vertical 9:16 aspect ratio videos.
- **WorkManager Reminders**: Periodic background workers for hydration (2h), posture check (3h), and sleep wind-down.
- **Moto G85 Companion Hub**: Device spec monitors, curved pOLED optimizations, and RAM/battery status.

---

## 🛠️ Setup & Installation

### Prerequisites
- Android Studio Iguana (2023.2.1) or newer
- JDK 17
- Android Device or Emulator running Android 10+ (API 29 to 34, optimized for Moto G85)

### Setup Steps
1. **Clone the repository**:
   ```bash
   git clone https://github.com/your-username/aanya-assistant.git
   cd aanya-assistant
   ```
2. **Open in Android Studio**:
   - File -> Open -> Select project root directory.
   - Wait for Gradle sync to complete.
3. **Configure Anthropic API Key (Optional)**:
   - In the app, navigate to the **Security** tab.
   - Enter your Anthropic Claude API key (`sk-ant-...`).
   - Tap **Save Key Securely** (stored in `EncryptedSharedPreferences` with AES-256 GCM).
   - *Note: If no key is set, Aanya seamlessly uses the built-in Hinglish fallback engine.*
4. **Grant Permissions on Moto G85**:
   - **Microphone**: Allow when prompted on first launch.
   - **Accessibility Service**: Go to *Settings -> Accessibility -> Downloaded Apps -> Aanya* and toggle **ON**.
   - **Notifications**: Allow notification posting for foreground task monitoring and wellness reminders.

---

## 🏗️ Project Architecture

```
app/src/main/java/com/example/
├── AanyaApp.kt                 # Application class & scheduler bootstrap
├── MainActivity.kt             # Main entry point with permission handlers
├── accessibility/
│   ├── AanyaAccessibilityService.kt # Safe AccessibilityService implementation
│   └── UiNavigator.kt          # Semantic UI tree search & actions
├── automation/
│   ├── AanyaForegroundService.kt # Foreground service with STOP ALL notification action
│   ├── AppLauncher.kt          # Safe app launcher with package blocklist
│   └── PhoneTaskRunner.kt      # Autonomous 12-step task execution loop
├── content/
│   ├── ContentStudio.kt        # Reels caption, hook, & hashtag generator
│   └── GallerySearcher.kt      # MediaStore vertical 9:16 query engine
├── database/
│   ├── AanyaDatabase.kt        # Room database with SQLite vault
│   ├── Daos.kt                 # Chat, Audit, Reminder, and Permission DAOs
│   └── Entities.kt             # Data entities
├── llm/
│   └── AnthropicClient.kt      # Anthropic Messages API client
├── notifications/
│   └── AanyaNotificationListenerService.kt # Focus summary listener
├── persona/
│   ├── AanyaPersonality.kt     # System prompt & boundary constraints
│   ├── CrisisGuard.kt          # Tele-MANAS (14416) & 112 crisis guard
│   └── LocalFallbackEngine.kt  # Offline Hinglish conversational engine
├── scheduler/
│   ├── ReminderWorker.kt       # WorkManager CoroutineWorker for notifications
│   └── ScheduleManager.kt      # Periodic wellness work scheduler
├── security/
│   ├── AuditLogger.kt          # In-memory and persistent action auditor
│   ├── EncryptedStorage.kt     # MasterKey AES-256 EncryptedSharedPreferences
│   ├── FinanceGuard.kt         # Package & sensitive keyword blocklist
│   └── KillSwitch.kt           # Instant emergency abort singleton
├── ui/
│   ├── MainScreen.kt           # Top bar, red STOP ALL button, 5 navigation tabs
│   ├── MainViewModel.kt        # State coordinator
│   ├── avatar/
│   │   ├── AvatarCanvas.kt     # Pure Compose Canvas animated girl avatar
│   │   └── AvatarModel.kt      # AvatarMood & VisualState
│   ├── screens/
│   │   ├── ChatScreen.kt       # Hinglish companion chat & voice mic
│   │   ├── ContentScreen.kt    # Reels generator & gallery explorer
│   │   ├── MotoScreen.kt       # Moto G85 hub & habit reminders
│   │   ├── SecurityScreen.kt   # Safety rules, audit logs & API key
│   │   └── TasksScreen.kt      # Phone automation execution monitor
│   └── theme/
│       ├── Color.kt            # Cyberpunk neon palette
│       ├── Theme.kt            # Dark futuristic Material3 theme
│       └── Type.kt             # Typography
```

---

## 🔒 Safety & Policy Compliance
- **No Financial Access**: Strict regex and package filters prevent opening or viewing banking apps.
- **No Password Interception**: `isPassword` and sensitive node detection immediately halts tasks.
- **User Confirmation**: Critical actions (*Share, Post, Send, Delete*) prompt an explicit confirmation dialog.
- **Emergency Kill Switch**: Pinned red STOP ALL button terminates all running processes immediately.
