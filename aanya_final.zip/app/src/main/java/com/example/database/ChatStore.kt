package com.example.database

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class ChatMessageEntity(
    val id: Long = 0,
    val role: String, // "user" or "assistant"
    val content: String,
    val mood: String = "NEUTRAL",
    val timestamp: Long = System.currentTimeMillis(),
    val isCrisis: Boolean = false
)

/**
 * Simple file-backed chat history (JSON in app-private storage).
 * Replaces Room so the build needs no annotation processor (KSP).
 */
class ChatStore(context: Context) {

    private val file = File(context.applicationContext.filesDir, "aanya_chat_history.json")
    private val mutex = Mutex()
    private var nextId = 1L

    private val _messages = MutableStateFlow<List<ChatMessageEntity>>(emptyList())
    val messages: StateFlow<List<ChatMessageEntity>> = _messages.asStateFlow()

    suspend fun load() = withContext(Dispatchers.IO) {
        mutex.withLock {
            try {
                if (!file.exists()) return@withLock
                val arr = JSONArray(file.readText())
                val list = ArrayList<ChatMessageEntity>(arr.length())
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(
                        ChatMessageEntity(
                            id = o.optLong("id"),
                            role = o.optString("role"),
                            content = o.optString("content"),
                            mood = o.optString("mood", "NEUTRAL"),
                            timestamp = o.optLong("timestamp"),
                            isCrisis = o.optBoolean("isCrisis", false)
                        )
                    )
                }
                nextId = (list.maxOfOrNull { it.id } ?: 0L) + 1
                _messages.value = list
            } catch (_: Exception) {
                // Corrupt file: start fresh
            }
        }
    }

    suspend fun insertMessage(message: ChatMessageEntity) = withContext(Dispatchers.IO) {
        mutex.withLock {
            val saved = message.copy(id = nextId++)
            val updated = (_messages.value + saved).takeLast(MAX_MESSAGES)
            _messages.value = updated
            persist(updated)
        }
    }

    /** Newest message first. */
    fun recentMessages(limit: Int): List<ChatMessageEntity> = _messages.value.takeLast(limit).reversed()

    suspend fun clear() = withContext(Dispatchers.IO) {
        mutex.withLock {
            _messages.value = emptyList()
            persist(emptyList())
        }
    }

    private fun persist(list: List<ChatMessageEntity>) {
        try {
            val arr = JSONArray()
            list.forEach {
                arr.put(
                    JSONObject()
                        .put("id", it.id)
                        .put("role", it.role)
                        .put("content", it.content)
                        .put("mood", it.mood)
                        .put("timestamp", it.timestamp)
                        .put("isCrisis", it.isCrisis)
                )
            }
            file.writeText(arr.toString())
        } catch (_: Exception) {
        }
    }

    companion object {
        private const val MAX_MESSAGES = 500
    }
}
