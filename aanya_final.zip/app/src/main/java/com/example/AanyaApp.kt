package com.example

import android.app.Application
import android.util.Log
import androidx.work.Configuration
import com.example.scheduler.ScheduleManager

class AanyaApp : Application(), Configuration.Provider {

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setMinimumLoggingLevel(Log.INFO)
            .build()

    override fun onCreate() {
        super.onCreate()
        try {
            // Initialize default wellness routines
            ScheduleManager.scheduleHydrationReminder(this, true)
            ScheduleManager.schedulePostureBreakReminder(this, true)
            ScheduleManager.scheduleSleepReminder(this, true)
        } catch (e: Exception) {
            Log.e("AanyaApp", "Init error: ${e.message}")
        }
    }
}
