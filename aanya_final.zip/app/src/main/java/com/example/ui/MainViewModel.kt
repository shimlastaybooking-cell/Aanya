package com.example.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.accessibility.AanyaAccessibilityService
import com.example.automation.ActiveTaskState
import com.example.automation.PhoneTaskRunner
import com.example.content.ContentIdea
import com.example.content.ContentStudio
import com.example.content.GalleryItem
import com.example.content.GallerySearcher
import com.example.database.ChatStore
import com.example.database.ChatMessageEntity
import com.example.llm.AnthropicClient
import com.example.llm.TaskActionJson
import com.example.persona.CrisisGuard
import com.example.persona.LocalFallbackEngine
import com.example.scheduler.ScheduleManager
import com.example.security.AuditEntry
import com.example.security.AuditLogger
import com.example.security.EncryptedStorage
import com.example.security.FinanceGuard
import com.example.security.KillSwitch
import com.example.ui.avatar.AvatarMood
import com.example.voice.VoiceManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ConfirmationDialogState(
    val isVisible: Boolean = false,
    val title: String = "",
    val message: String = "",
    val onConfirm: () -> Unit = {},
    val onDismiss: () -> Unit = {}
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val chatStore = ChatStore(application)
    private val encryptedStorage = EncryptedStorage(application)
    private val anthropicClient = AnthropicClient()
    private val phoneTaskRunner = PhoneTaskRunner(application, encryptedStorage, anthropicClient)

    // UI Tab Navigation
    private val _selectedTab = MutableStateFlow(0) // 0: Chat, 1: Tasks, 2: Content, 3: Moto/Brand, 4: Security
    val selectedTab: StateFlow<Int> = _selectedTab.asStateFlow()

    // Avatar State
    private val _currentMood = MutableStateFlow(AvatarMood.NEUTRAL)
    val currentMood: StateFlow<AvatarMood> = _currentMood.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _isConversationMode = MutableStateFlow(false)
    val isConversationMode: StateFlow<Boolean> = _isConversationMode.asStateFlow()

    // Confirmation Dialog State
    private val _confirmationDialog = MutableStateFlow(ConfirmationDialogState())
    val confirmationDialog: StateFlow<ConfirmationDialogState> = _confirmationDialog.asStateFlow()

    // Chat History
    val chatMessages: StateFlow<List<ChatMessageEntity>> = chatStore.messages

    // Audit Logs
    val auditLogs: StateFlow<List<AuditEntry>> = AuditLogger.logs

    // Phone Tasks State
    val taskState: StateFlow<ActiveTaskState> = phoneTaskRunner.taskState

    // Content Ideas
    private val _viralIdeas = MutableStateFlow<List<ContentIdea>>(ContentStudio.generateViralIdeas("aesthetic / lifestyle", "Daily Vibe"))
    val viralIdeas: StateFlow<List<ContentIdea>> = _viralIdeas.asStateFlow()

    // Gallery Media
    private val _galleryItems = MutableStateFlow<List<GalleryItem>>(emptyList())
    val galleryItems: StateFlow<List<GalleryItem>> = _galleryItems.asStateFlow()

    // Anthropic API Key
    private val _apiKey = MutableStateFlow(encryptedStorage.getAnthropicApiKey())
    val apiKey: StateFlow<String> = _apiKey.asStateFlow()

    // Voice Manager
    private var voiceManager: VoiceManager? = null

    init {
        viewModelScope.launch { chatStore.load() }
        initVoice(application)
        observeKillSwitch()
        loadInitialMedia(application)
    }

    private fun initVoice(context: Context) {
        voiceManager = VoiceManager(
            context = context,
            onSpeechResult = { recognizedText ->
                sendMessage(recognizedText)
            },
            onSpeakingStateChanged = { speaking ->
                _isSpeaking.value = speaking
            }
        )
        // Keep UI state in sync with the real recognizer state (auto-restart, errors, end of speech)
        voiceManager?.let { vm ->
            viewModelScope.launch { vm.isListening.collect { _isListening.value = it } }
            viewModelScope.launch { vm.isConversationMode.collect { _isConversationMode.value = it } }
        }
    }

    private fun observeKillSwitch() {
        viewModelScope.launch {
            KillSwitch.stopEvents.collect {
                // Instantly halt speech, mic, task
                voiceManager?.stopSpeaking()
                voiceManager?.stopListening()
                _isSpeaking.value = false
                _isListening.value = false
                _currentMood.value = AvatarMood.NEUTRAL
            }
        }
    }

    private fun loadInitialMedia(context: Context) {
        viewModelScope.launch {
            _galleryItems.value = GallerySearcher.queryMedia(context)
        }
    }

    fun selectTab(tabIndex: Int) {
        _selectedTab.value = tabIndex
    }

    fun setMood(mood: AvatarMood) {
        _currentMood.value = mood
    }

    fun toggleConversationMode() {
        val active = voiceManager?.toggleConversationMode() ?: false
        _isConversationMode.value = active
        _isListening.value = active
    }

    fun startPushToTalk() {
        voiceManager?.startListening()
        _isListening.value = true
    }

    fun stopPushToTalk() {
        voiceManager?.stopListening()
        _isListening.value = false
    }

    fun stopAllEmergency() {
        KillSwitch.triggerEmergencyStop("Top Red STOP ALL Button")
        phoneTaskRunner.stopTask()
        voiceManager?.stopSpeaking()
        voiceManager?.stopListening()
        _isSpeaking.value = false
        _isListening.value = false
        _isConversationMode.value = false
        _currentMood.value = AvatarMood.NEUTRAL
    }

    fun saveAnthropicApiKey(key: String) {
        encryptedStorage.setAnthropicApiKey(key)
        _apiKey.value = key
        AuditLogger.log(
            actionType = "KEY_UPDATED",
            targetApp = "Security Center",
            description = "Anthropic API Key updated in encrypted storage",
            status = "SUCCESS"
        )
    }

    fun sendMessage(userText: String) {
        if (userText.isBlank()) return

        viewModelScope.launch {
            // Save user message
            val userMsg = ChatMessageEntity(
                role = "user",
                content = userText
            )
            chatStore.insertMessage(userMsg)

            // 1. Crisis Check (Tele-MANAS 14416 & 112)
            if (CrisisGuard.detectCrisis(userText)) {
                val crisisReply = CrisisGuard.getCrisisResponse()
                _currentMood.value = AvatarMood.CARING
                val assistantMsg = ChatMessageEntity(
                    role = "assistant",
                    content = crisisReply,
                    mood = "CARING",
                    isCrisis = true
                )
                chatStore.insertMessage(assistantMsg)
                voiceManager?.speak(crisisReply)
                return@launch
            }

            // 2. Financial Command Refusal
            val (refused, refusalReason) = FinanceGuard.isCommandRefused(userText)
            if (refused) {
                val reply = refusalReason ?: "Aanya: Financial apps are blocked by safety rules! 🛡️"
                _currentMood.value = AvatarMood.NEUTRAL
                val assistantMsg = ChatMessageEntity(
                    role = "assistant",
                    content = reply,
                    mood = "NEUTRAL"
                )
                chatStore.insertMessage(assistantMsg)
                voiceManager?.speak(reply)
                return@launch
            }

            // 3. Anthropic Messages API or Local Fallback Engine
            val currentKey = _apiKey.value
            if (currentKey.isNotBlank()) {
                _currentMood.value = AvatarMood.THINKING
                // Recent messages for context (newest first -> drop the message we just saved,
                // reverse to chronological order, and make sure it starts with a user turn).
                val history = chatStore.recentMessages(7)
                    .drop(1)
                    .reversed()
                    .dropWhile { !it.role.equals("user", ignoreCase = true) }
                    .map { it.role to it.content }
                val anthropicRes = anthropicClient.sendChatMessage(
                    apiKey = currentKey,
                    conversationHistory = history,
                    userMessage = userText
                )

                if (anthropicRes.isSuccess) {
                    val reply = anthropicRes.getOrThrow()
                    _currentMood.value = AvatarMood.HAPPY
                    val assistantMsg = ChatMessageEntity(
                        role = "assistant",
                        content = reply,
                        mood = "HAPPY"
                    )
                    chatStore.insertMessage(assistantMsg)
                    voiceManager?.speak(reply)
                    return@launch
                }
            }

            // Local Fallback Hinglish Engine
            val fallback = LocalFallbackEngine.generateReply(userText)
            _currentMood.value = fallback.mood
            val assistantMsg = ChatMessageEntity(
                role = "assistant",
                content = fallback.text,
                mood = fallback.mood.name
            )
            chatStore.insertMessage(assistantMsg)
            voiceManager?.speak(fallback.text)
        }
    }

    fun startPhoneTask(goal: String) {
        viewModelScope.launch {
            phoneTaskRunner.startPhoneTask(goal) { actionToConfirm, callback ->
                // Show safety confirmation dialog before execution
                showConfirmationDialog(
                    title = "Confirm Sensitive Action 🛡️",
                    message = "Aanya is about to execute: ${actionToConfirm.action.uppercase()} on '${actionToConfirm.target}'.\nExplanation: ${actionToConfirm.explanation}\n\nKya aap proceed karna chahte hain?",
                    onConfirm = {
                        dismissConfirmationDialog()
                        callback(true)
                    },
                    onDismiss = {
                        dismissConfirmationDialog()
                        callback(false)
                    }
                )
            }
        }
    }

    fun stopPhoneTask() {
        phoneTaskRunner.stopTask()
    }

    fun generateViralContent(category: String, topic: String) {
        _viralIdeas.value = ContentStudio.generateViralIdeas(category, topic)
    }

    fun refreshGallery(onlyVertical: Boolean, query: String) {
        viewModelScope.launch {
            _galleryItems.value = GallerySearcher.queryMedia(
                getApplication(),
                onlyVertical9x16 = onlyVertical,
                searchQuery = query
            )
        }
    }

    fun setReminderEnabled(reminderId: String, enabled: Boolean) {
        when (reminderId) {
            "hydration" -> ScheduleManager.scheduleHydrationReminder(getApplication(), enabled)
            "posture" -> ScheduleManager.schedulePostureBreakReminder(getApplication(), enabled)
            "sleep" -> ScheduleManager.scheduleSleepReminder(getApplication(), enabled)
        }
    }

    fun showConfirmationDialog(
        title: String,
        message: String,
        onConfirm: () -> Unit,
        onDismiss: () -> Unit
    ) {
        _confirmationDialog.value = ConfirmationDialogState(
            isVisible = true,
            title = title,
            message = message,
            onConfirm = onConfirm,
            onDismiss = onDismiss
        )
    }

    fun dismissConfirmationDialog() {
        _confirmationDialog.value = _confirmationDialog.value.copy(isVisible = false)
    }

    override fun onCleared() {
        super.onCleared()
        voiceManager?.destroy()
    }
}
