package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.persona.CrisisGuard
import com.example.persona.LocalFallbackEngine
import com.example.security.FinanceGuard
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context matches Aanya`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Aanya", appName)
  }

  @Test
  fun `finance guard blocks banking and upi packages`() {
    assertTrue(FinanceGuard.isPackageBlocked("com.google.android.apps.nbu.paisa.user")) // GPay
    assertTrue(FinanceGuard.isPackageBlocked("net.one97.paytm")) // Paytm
    assertTrue(FinanceGuard.isPackageBlocked("com.phonepe.app")) // PhonePe
    assertTrue(FinanceGuard.isPackageBlocked("com.zerodha.kite3")) // Zerodha
    assertTrue(FinanceGuard.isPackageBlocked("com.android.settings")) // Settings

    val (refused, _) = FinanceGuard.isCommandRefused("transfer money to account")
    assertTrue(refused)
  }

  @Test
  fun `crisis guard detects distress and provides Tele-MANAS helpline`() {
    assertTrue(CrisisGuard.detectCrisis("i want to end my life"))
    val reply = CrisisGuard.getCrisisResponse()
    assertTrue(reply.contains("14416"))
    assertTrue(reply.contains("112"))
  }

  @Test
  fun `local fallback engine is honest about being AI`() {
    val reply = LocalFallbackEngine.generateReply("Are you an AI?")
    assertTrue(reply.text.contains("AI", ignoreCase = true))
  }
}
