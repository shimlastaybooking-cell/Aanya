package com.example.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ChatMessageEntity::class,
        AuditLogEntity::class,
        WellnessReminderEntity::class,
        AppPermissionEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AanyaDatabase : RoomDatabase() {
    abstract fun chatDao(): ChatDao
    abstract fun auditDao(): AuditDao
    abstract fun reminderDao(): ReminderDao
    abstract fun appPermissionDao(): AppPermissionDao

    companion object {
        @Volatile
        private var INSTANCE: AanyaDatabase? = null

        fun getInstance(context: Context): AanyaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AanyaDatabase::class.java,
                    "aanya_encrypted_vault.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
