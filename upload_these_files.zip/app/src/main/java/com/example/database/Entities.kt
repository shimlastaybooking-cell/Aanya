package com.example.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String, // "user" or "assistant"
    val content: String,
    val mood: String = "NEUTRAL",
    val timestamp: Long = System.currentTimeMillis(),
    val isCrisis: Boolean = false
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: String,
    val actionType: String,
    val targetApp: String,
    val description: String,
    val status: String,
    val isSafetyIntervention: Boolean
)

@Entity(tableName = "wellness_reminders")
data class WellnessReminderEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val intervalHours: Int,
    val isEnabled: Boolean
)

@Entity(tableName = "app_permissions")
data class AppPermissionEntity(
    @PrimaryKey val packageName: String,
    val appName: String,
    val isAllowed: Boolean
)
