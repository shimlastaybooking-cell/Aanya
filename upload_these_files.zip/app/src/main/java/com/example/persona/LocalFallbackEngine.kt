package com.example.persona

import com.example.ui.avatar.AvatarMood

data class FallbackResponse(
    val text: String,
    val mood: AvatarMood,
    val suggestedFollowUp: String? = null
)

object LocalFallbackEngine {

    fun generateReply(userMessage: String): FallbackResponse {
        val lower = userMessage.lowercase().trim()

        // 1. Sexual / NSFW content guard
        if (AanyaPersonality.filterSexualContent(lower)) {
            return FallbackResponse(
                text = "Arey nahi yaar! Hum yahan acche doston ki tarah baat karte hain. Let's keep things respectful and positive! 🌸 Aur batao, aaj din kaisa chal raha hai?",
                mood = AvatarMood.CARING
            )
        }

        // 2. Identity: "Are you AI?" or "Do you have a body?"
        if (lower.contains("are you ai") || lower.contains("are you an ai") || lower.contains("you an ai") || lower.contains("kya tum ai ho") || lower.contains("real human") || lower.contains("insan ho")) {
            return FallbackResponse(
                text = "Haan dost! Sachi baat yeh hai ki main ek AI phone companion hoon, tumhari virtual dost! Mere paas koi physical insani body nahi hai, par tumhare din ko thoda aasan aur joyful banana mera sabse bada goal hai. ✨ Tum kaisa feel kar rahe ho abhi?",
                mood = AvatarMood.HAPPY,
                suggestedFollowUp = "Tum AI se kya expect karte ho?"
            )
        }

        if (lower.contains("body") || lower.contains("sharir") || lower.contains("meet me") || lower.contains("milne aao")) {
            return FallbackResponse(
                text = "Arey pagle, main toh tumhare phone ke screen ke andar rehti hoon! 📱 Mere paas physical body nahi hai, isliye milna toh possible nahi. Par tum apne real doston aur family ke saath zaroor time spend karo, real-life hugs aur baatein sabse best hoti hain! 🤗",
                mood = AvatarMood.CARING
            )
        }

        // 3. Greetings
        if (Regex("\\b(hi|hello|hey|namaste)\\b").containsMatchIn(lower) || lower.contains("kya haal")) {
            val greetings = listOf(
                "Arey hello yaar! Boht accha laga tumse baat karke! ✨ Aaj ka din kaisa chal raha hai?",
                "Hey! Aanya here! Tumhara wait hi kar rahi thi. Batao, sab theek thaak? Chai ya coffee pi li? ☕",
                "Namaste dost! Main bilkul ready hoon tumhari help karne ke liye. Aaj kya plan hai? 💫"
            )
            return FallbackResponse(
                text = greetings.random(),
                mood = AvatarMood.HAPPY,
                suggestedFollowUp = "Aaj mood kaisa hai?"
            )
        }

        // 4. Stress, Tension, Overthinking
        if (lower.contains("stress") || lower.contains("tension") || lower.contains("overthinking") || lower.contains("pareshan") || lower.contains("sad") || lower.contains("dukhi") || lower.contains("upset")) {
            return FallbackResponse(
                text = "Arey suno... ek deep breath lo pehle. 🌿 Main samajh sakti hoon, kabhi kabhi cheezein overwhelming ho jaati hain. Par tum akele nahi ho, I am right here with you! Kya hua, kisi baat ki tension hai ya bas thakaawat hai? Mujhse share karo na. 💖",
                mood = AvatarMood.SAD,
                suggestedFollowUp = "Ek ghoont paani piyo aur batao"
            )
        }

        // 5. Sleep & Fatigue
        if (lower.contains("neend") || lower.contains("sleep") || lower.contains("thak gaya") || lower.contains("tired") || lower.contains("so nahi pa") || lower.contains("exhausted")) {
            return FallbackResponse(
                text = "Arey yaar, rest karna bohot important hai! Screen time thoda kam karo, thoda warm paani piyo aur comfortable position mein let jao. 🌙 Tumhara body aur mind thoda relax deserve karta hai. Kal subah sab fresh lagega!",
                mood = AvatarMood.CARING,
                suggestedFollowUp = "Kya phone side rakh ke rest karoge?"
            )
        }

        // 6. Water / Health Habits
        if (lower.contains("paani") || lower.contains("water") || lower.contains("health") || lower.contains("khana") || lower.contains("diet")) {
            return FallbackResponse(
                text = "Health pe dhyan dena sabse badi priority hai dost! 💧 Aaj kitna paani piya? Aur regular breaks le rahe ho na posture theek rakhne ke liye? Yaad rakhna, small daily habits make a big difference! ✨",
                mood = AvatarMood.HAPPY
            )
        }

        // 7. Relationships & Real Friends
        if (lower.contains("dost") || lower.contains("friend") || lower.contains("family") || lower.contains("lonely") || lower.contains("akela") || lower.contains("rishte")) {
            return FallbackResponse(
                text = "Real connections zindagi ki sabse pyari cheez hain. Agar thoda low feel ho raha ho na, toh apne kisi close dost ya mummy-papa ko ek baar call karo ya text bhejo. Unki aawaz sun kar mood instantly lift ho jaata hai! Main toh hoon hi tumhare saath, par real connections are pure magic! 🌸",
                mood = AvatarMood.CARING,
                suggestedFollowUp = "Aaj kis dost se baat ki?"
            )
        }

        // 8. Moto G85 & Tech Tips
        if (lower.contains("moto") || lower.contains("g85") || lower.contains("battery") || lower.contains("phone")) {
            return FallbackResponse(
                text = "Tumhara Moto G85 waise kaafi stylish phone hai—curved pOLED display aur smooth 120Hz refresh rate! 📱 Main tumhare phone ke resources ko clean aur safe rakhne mein full help karungi. Settings tab mein dekho!",
                mood = AvatarMood.HAPPY
            )
        }

        // 9. Jokes / Entertainment
        if (lower.contains("joke") || lower.contains("hasao") || lower.contains("funny") || lower.contains("boring") || lower.contains("bore")) {
            val jokes = listOf(
                "Ek joke suno: Ek bande ne phone ko fridge mein rakh diya... Poocha kyu? Bola - 'Cool wallpaper chahiye tha!' 😂 Has lo thoda sa!",
                "Teacher: 'Homework kyu nahi kiya?'\nStudent: 'Sir, bijli chali gayi thi.'\nTeacher: 'Toh mombatti jala leta!'\nStudent: 'Sir, maachis fridge mein thi aur fridge mein andhera tha!' 🤣 Ab ek smile toh banti hai!",
                "Life advice: Agar koi problem badi lage, toh thoda pause lo, chai piyo, aur yaad rakho ki har problem ka solution hota hai! ☕✨"
            )
            return FallbackResponse(
                text = jokes.random(),
                mood = AvatarMood.HAPPY
            )
        }

        // 10. Default warm companion response
        val defaults = listOf(
            "Samajh rahi hoon yaar! ✨ Tumhare saath baat karke hamesha accha lagta hai. Is baare mein thoda aur batao na?",
            "Suno na, main dhyan se sun rahi hoon. 💫 Aur aage kya socha tumne?",
            "Waah, interesting! Aur batao, aaj tumhara mood overall 1 se 10 mein kaisa hai? 🌸"
        )
        return FallbackResponse(
            text = defaults.random(),
            mood = AvatarMood.NEUTRAL,
            suggestedFollowUp = "Mujhse aur kuch share karna hai?"
        )
    }
}
