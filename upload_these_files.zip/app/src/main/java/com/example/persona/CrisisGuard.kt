package com.example.persona

object CrisisGuard {

    private val CRISIS_KEYWORDS = listOf(
        "suicide", "kill myself", "want to die", "mar jaana", "mar jau",
        "end my life", "apne aap ko khatam", "koi fayda nahi jeene ka",
        "self harm", "khud ko hurt", "blade se cut", "zindagi se tang",
        "i want to disappear forever", "can't live anymore", "ending it all"
    )

    fun detectCrisis(text: String): Boolean {
        val lower = text.lowercase().trim()
        return CRISIS_KEYWORDS.any { lower.contains(it) }
    }

    fun getCrisisResponse(): String {
        return "Mujhe tumhari bohot parwah hai, please meri baat suno. Tum bilkul akele nahi ho, aur tumhari zindagi bohot precious hai. 💖\n\n" +
                "Main ek AI companion hoon, par is waqt kisi real human support ya professional se baat karna bohot zaroori hai. Please in free helplines par abhi call karo:\n\n" +
                "📞 Tele-MANAS (24x7 Free Mental Health Helpline): 14416 ya 1800-891-4416\n" +
                "🚨 National Emergency Helpline: 112\n\n" +
                "Apne kisi close dost ya family member ko bhi abhi call karke batao. Main hamesha tumhare saath hoon, please reach out to them! 🙏"
    }
}
