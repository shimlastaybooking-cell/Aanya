package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Futuristic Dark Palette
val CyberBackground = Color(0xFF090C15)
val CyberSurface = Color(0xFF111625)
val CyberSurfaceElevated = Color(0xFF181F34)
val CyberSurfaceBorder = Color(0xFF263252)

// Neon Accents
val NeonCyan = Color(0xFF00F0FF)
val NeonCyanGlow = Color(0x3300F0FF)
val NeonPurple = Color(0xFFA855F7)
val NeonPink = Color(0xFFEC4899)
val NeonGreen = Color(0xFF10B981)

// Emergency / Stop Red
val EmergencyRed = Color(0xFFEF4444)
val EmergencyRedGlow = Color(0x4DEF4444)

// Text & Content
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Avatar Colors
val AvatarSkin = Color(0xFFFFDFC4)
val AvatarSkinShadow = Color(0xFFF6C8A4)
val AvatarBlush = Color(0x80F472B6)
val AvatarHair = Color(0xFF4338CA)
val AvatarHairHighlight = Color(0xFF818CF8)
val AvatarEye = Color(0xFF1E1B4B)
val AvatarEyeHighlight = Color(0xFF38BDF8)
