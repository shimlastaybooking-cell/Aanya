package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.avatar.AanyaAvatar
import com.example.ui.avatar.AvatarMood
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.ContentScreen
import com.example.ui.screens.MotoScreen
import com.example.ui.screens.SecurityScreen
import com.example.ui.screens.TasksScreen
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceBorder
import com.example.ui.theme.EmergencyRed
import com.example.ui.theme.EmergencyRedGlow
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun MainScreen(viewModel: MainViewModel) {
    val selectedTab by viewModel.selectedTab.collectAsState()
    val currentMood by viewModel.currentMood.collectAsState()
    val isSpeaking by viewModel.isSpeaking.collectAsState()
    val isListening by viewModel.isListening.collectAsState()
    val isConversationMode by viewModel.isConversationMode.collectAsState()
    val confirmationDialog by viewModel.confirmationDialog.collectAsState()

    val chatMessages by viewModel.chatMessages.collectAsState()
    val auditLogs by viewModel.auditLogs.collectAsState()
    val taskState by viewModel.taskState.collectAsState()
    val viralIdeas by viewModel.viralIdeas.collectAsState()
    val galleryItems by viewModel.galleryItems.collectAsState()
    val apiKey by viewModel.apiKey.collectAsState()

    Scaffold(
        containerColor = CyberBackground,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            // Futuristic Top Bar with Moto G85 status & prominent RED STOP ALL button
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CyberSurface)
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Logo & Moto G85 status chip
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(NeonCyan.copy(alpha = 0.2f))
                                .border(1.dp, NeonCyan, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("Aa", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "AANYA",
                                    color = TextPrimary,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 15.sp,
                                    letterSpacing = 1.sp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(NeonPurple.copy(alpha = 0.25f))
                                        .padding(horizontal = 5.dp, vertical = 2.dp)
                                ) {
                                    Text("Moto G85", color = NeonPurple, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Text(
                                text = "Personal Phone Companion",
                                color = TextMuted,
                                fontSize = 10.sp
                            )
                        }
                    }

                    // Always-visible RED STOP ALL button
                    Button(
                        onClick = { viewModel.stopAllEmergency() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = EmergencyRed,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(20.dp),
                        elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp),
                        modifier = Modifier
                            .testTag("stop_all_button")
                            .border(1.dp, Color(0xFFFF8A80), RoundedCornerShape(20.dp))
                    ) {
                        Icon(
                            imageVector = Icons.Default.StopCircle,
                            contentDescription = "Stop All",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "STOP ALL",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 12.sp,
                            letterSpacing = 0.5.sp
                        )
                    }
                }
            }
        },
        bottomBar = {
            // 5 Bottom Tabs: Chat, Tasks, Content, Brand (Moto), Security
            NavigationBar(
                containerColor = CyberSurface,
                tonalElevation = 8.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        width = 1.dp,
                        color = CyberSurfaceBorder,
                        shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
                    )
            ) {
                val navItems = listOf(
                    Triple(0, "Chat", Icons.Default.Chat),
                    Triple(1, "Tasks", Icons.Default.Assignment),
                    Triple(2, "Content", Icons.Default.VideoLibrary),
                    Triple(3, "Brand", Icons.Default.PhoneAndroid),
                    Triple(4, "Security", Icons.Default.Security)
                )

                navItems.forEach { (index, label, icon) ->
                    val selected = selectedTab == index
                    NavigationBarItem(
                        selected = selected,
                        onClick = { viewModel.selectTab(index) },
                        icon = {
                            Icon(
                                imageVector = icon,
                                contentDescription = label,
                                tint = if (selected) NeonCyan else TextMuted
                            )
                        },
                        label = {
                            Text(
                                text = label,
                                fontSize = 10.sp,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                color = if (selected) NeonCyan else TextMuted
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = NeonCyan.copy(alpha = 0.15f)
                        ),
                        modifier = Modifier.testTag("nav_tab_$label")
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Avatar Header (Shown prominently, breathing & blinking & lip-syncing)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberSurfaceBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Compose Canvas Avatar
                    AanyaAvatar(
                        mood = currentMood,
                        isSpeaking = isSpeaking,
                        isListening = isListening,
                        modifier = Modifier.size(76.dp)
                    )

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Aanya",
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(
                                        when (currentMood) {
                                            AvatarMood.HAPPY -> Color(0xFF1E3A2F)
                                            AvatarMood.CARING -> Color(0xFF381A2D)
                                            AvatarMood.SAD -> Color(0xFF2E241E)
                                            else -> Color(0xFF1E293B)
                                        }
                                    )
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "${currentMood.emoji} ${currentMood.displayName}",
                                    color = when (currentMood) {
                                        AvatarMood.HAPPY -> Color(0xFF34D399)
                                        AvatarMood.CARING -> Color(0xFFF472B6)
                                        AvatarMood.SAD -> Color(0xFFFBBF24)
                                        else -> NeonCyan
                                    },
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(2.dp))

                        Text(
                            text = if (isSpeaking) "Speaking with cheerful voice... 💬"
                            else if (isListening) "Listening carefully to you... 🎙️"
                            else "Hinglish AI Companion • Moto G85",
                            color = if (isSpeaking || isListening) NeonCyan else TextSecondary,
                            fontSize = 11.sp
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        // Quick Mood Selector Chips
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            MoodMiniChip("✨ Calm", AvatarMood.NEUTRAL, currentMood == AvatarMood.NEUTRAL) {
                                viewModel.setMood(AvatarMood.NEUTRAL)
                            }
                            MoodMiniChip("😄 Happy", AvatarMood.HAPPY, currentMood == AvatarMood.HAPPY) {
                                viewModel.setMood(AvatarMood.HAPPY)
                            }
                            MoodMiniChip("💖 Caring", AvatarMood.CARING, currentMood == AvatarMood.CARING) {
                                viewModel.setMood(AvatarMood.CARING)
                            }
                            MoodMiniChip("🥺 Soft", AvatarMood.SAD, currentMood == AvatarMood.SAD) {
                                viewModel.setMood(AvatarMood.SAD)
                            }
                        }
                    }
                }
            }

            // Tab Content
            Box(modifier = Modifier.weight(1f)) {
                when (selectedTab) {
                    0 -> ChatScreen(
                        messages = chatMessages,
                        isConversationMode = isConversationMode,
                        isListening = isListening,
                        onToggleConversationMode = { viewModel.toggleConversationMode() },
                        onStartPushToTalk = { viewModel.startPushToTalk() },
                        onStopPushToTalk = { viewModel.stopPushToTalk() },
                        onSendMessage = { viewModel.sendMessage(it) }
                    )
                    1 -> TasksScreen(
                        taskState = taskState,
                        onStartTask = { viewModel.startPhoneTask(it) },
                        onStopTask = { viewModel.stopPhoneTask() }
                    )
                    2 -> ContentScreen(
                        viralIdeas = viralIdeas,
                        galleryItems = galleryItems,
                        onGenerateIdeas = { cat, topic -> viewModel.generateViralContent(cat, topic) },
                        onFilterGallery = { only9x16, query -> viewModel.refreshGallery(only9x16, query) },
                        onRequestConfirmation = { title, msg, onConfirm ->
                            viewModel.showConfirmationDialog(title, msg, onConfirm, {})
                        }
                    )
                    3 -> MotoScreen(
                        onToggleReminder = { id, enabled -> viewModel.setReminderEnabled(id, enabled) }
                    )
                    4 -> SecurityScreen(
                        auditLogs = auditLogs,
                        apiKey = apiKey,
                        onSaveApiKey = { viewModel.saveAnthropicApiKey(it) }
                    )
                }
            }
        }
    }

    // Safety Confirmation Dialog for Sensitive Actions (Send/Post/Delete/Publish)
    if (confirmationDialog.isVisible) {
        AlertDialog(
            onDismissRequest = { confirmationDialog.onDismiss() },
            title = {
                Text(
                    text = confirmationDialog.title,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                Text(
                    text = confirmationDialog.message,
                    color = TextSecondary,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = { confirmationDialog.onConfirm() },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                    modifier = Modifier.testTag("dialog_confirm_button")
                ) {
                    Text("Confirm & Proceed", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { confirmationDialog.onDismiss() },
                    modifier = Modifier.testTag("dialog_cancel_button")
                ) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = CyberSurface,
            shape = RoundedCornerShape(16.dp)
        )
    }
}

@Composable
private fun MoodMiniChip(
    label: String,
    mood: AvatarMood,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (isSelected) NeonCyan.copy(alpha = 0.25f) else CyberSurfaceBorder.copy(alpha = 0.5f))
            .border(
                1.dp,
                if (isSelected) NeonCyan else Color.Transparent,
                RoundedCornerShape(6.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 2.dp)
            .testTag("mood_chip_${mood.name.lowercase()}"),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (isSelected) NeonCyan else TextMuted,
            fontSize = 9.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}
