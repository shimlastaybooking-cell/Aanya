package com.example.ui.avatar

enum class AvatarMood(val displayName: String, val emoji: String) {
    NEUTRAL("Calm & Focused", "✨"),
    HAPPY("Joyful & Energetic", "😄"),
    SAD("Soft & Reflective", "🥺"),
    CARING("Warm & Loving", "💖"),
    THINKING("Thinking...", "🧠")
}

data class AvatarVisualState(
    val mood: AvatarMood = AvatarMood.NEUTRAL,
    val isSpeaking: Boolean = false,
    val isListening: Boolean = false,
    val breathScale: Float = 1.0f,
    val breathOffsetY: Float = 0f,
    val blinkProgress: Float = 0f, // 0f = open, 1f = fully closed
    val mouthOpenAmount: Float = 0f // 0f = closed, 1f = open wide
)
