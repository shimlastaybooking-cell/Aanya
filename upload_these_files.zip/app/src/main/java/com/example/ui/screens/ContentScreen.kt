package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CropFree
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.SuggestionChipDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.content.ContentIdea
import com.example.content.ContentStudio
import com.example.content.GalleryItem
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceBorder
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.EmergencyRed
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ContentScreen(
    viralIdeas: List<ContentIdea>,
    galleryItems: List<GalleryItem>,
    onGenerateIdeas: (String, String) -> Unit,
    onFilterGallery: (Boolean, String) -> Unit,
    onRequestConfirmation: (String, String, () -> Unit) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedCategory by remember { mutableStateOf("aesthetic / lifestyle") }
    var topicQuery by remember { mutableStateOf("") }
    var only9x16 by remember { mutableStateOf(true) }
    var selectedMediaUri by remember { mutableStateOf<Uri?>(null) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Content Studio Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberSurfaceBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = "Studio", tint = NeonPurple)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Aanya Content Studio 🎬",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Create viral Instagram Reels, generate Hinglish captions & hashtags, and prepare 9:16 vertical video assets.",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Category filters
                    val categories = listOf("aesthetic / lifestyle", "tech & tips", "motivation / friendship")
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(categories) { cat ->
                            FilterChip(
                                selected = selectedCategory == cat,
                                onClick = {
                                    selectedCategory = cat
                                    onGenerateIdeas(cat, topicQuery)
                                },
                                label = { Text(cat.replaceFirstChar { it.uppercase() }, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = NeonPurple,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = topicQuery,
                            onValueChange = { topicQuery = it },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("content_topic_input"),
                            placeholder = { Text("Topic: e.g. Morning routine, Moto G85...", fontSize = 12.sp, color = TextMuted) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonCyan,
                                unfocusedBorderColor = CyberSurfaceBorder,
                                focusedContainerColor = CyberSurfaceElevated,
                                unfocusedContainerColor = CyberSurfaceElevated
                            ),
                            shape = RoundedCornerShape(10.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { onGenerateIdeas(selectedCategory, topicQuery) },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                            modifier = Modifier.testTag("generate_ideas_button")
                        ) {
                            Text("Generate", color = Color(0xFF03141A), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // 2. Generated Reel Ideas
        item {
            Text(
                text = "Viral Reel Ideas (${viralIdeas.size})",
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
            )
        }

        items(viralIdeas) { idea ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CyberSurfaceElevated),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberSurfaceBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(idea.title, color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Hook: \"${idea.hook}\"", color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Caption: ${idea.caption}", color = TextSecondary, fontSize = 12.sp, lineHeight = 17.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Vibe: 🎵 ${idea.musicVibe}", color = NeonPurple, fontSize = 11.sp)

                    Spacer(modifier = Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                onRequestConfirmation(
                                    "Share Instagram Reel 📸",
                                    "Kya aap Instagram open karke is caption ke saath Reel share karna chahte hain?"
                                ) {
                                    val shareIntent = ContentStudio.createInstagramShareIntent(selectedMediaUri)
                                    context.startActivity(Intent.createChooser(shareIntent, "Share to Instagram"))
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE1306C)),
                            modifier = Modifier.testTag("share_instagram_button")
                        ) {
                            Icon(Icons.Default.Share, contentDescription = "Share", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Share Reel (Confirm)", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // 3. MediaStore 9:16 Gallery Search & Crop Helper
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberSurfaceBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.PhotoLibrary, contentDescription = "Gallery", tint = NeonCyan)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Phone Gallery & 9:16 Crop", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }

                        FilterChip(
                            selected = only9x16,
                            onClick = {
                                only9x16 = !only9x16
                                onFilterGallery(only9x16, "")
                            },
                            label = { Text("9:16 Reels Only", fontSize = 11.sp) }
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "MediaStore query finds videos formatted for vertical 9:16 phone screens (Reels/Shorts).",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    if (galleryItems.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(90.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(CyberSurfaceElevated),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("No matching 9:16 media found in gallery", color = TextMuted, fontSize = 12.sp)
                        }
                    } else {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(galleryItems.take(15)) { media ->
                                val isSelected = selectedMediaUri == media.uri
                                Box(
                                    modifier = Modifier
                                        .size(90.dp, 130.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(CyberSurfaceElevated)
                                        .border(
                                            2.dp,
                                            if (isSelected) NeonCyan else CyberSurfaceBorder,
                                            RoundedCornerShape(10.dp)
                                        )
                                        .clickable { selectedMediaUri = media.uri }
                                        .padding(8.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.fillMaxSize(),
                                        verticalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            if (media.isVideo) "VIDEO" else "IMAGE",
                                            color = NeonPurple,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            media.displayName.take(16),
                                            color = TextPrimary,
                                            fontSize = 10.sp,
                                            maxLines = 2
                                        )
                                        if (media.isVertical9x16) {
                                            Text("9:16", color = NeonCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
