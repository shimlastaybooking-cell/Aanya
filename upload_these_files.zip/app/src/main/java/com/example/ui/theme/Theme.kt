package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = NeonCyan,
    onPrimary = Color(0xFF03141A),
    primaryContainer = Color(0xFF0E384D),
    onPrimaryContainer = Color(0xFFBAE6FD),
    secondary = NeonPurple,
    onSecondary = Color(0xFF1E0B38),
    secondaryContainer = Color(0xFF381E6D),
    onSecondaryContainer = Color(0xFFE9D5FF),
    tertiary = NeonPink,
    onTertiary = Color(0xFF36081E),
    tertiaryContainer = Color(0xFF5C1637),
    onTertiaryContainer = Color(0xFFFBCFE8),
    background = CyberBackground,
    onBackground = TextPrimary,
    surface = CyberSurface,
    onSurface = TextPrimary,
    surfaceVariant = CyberSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = CyberSurfaceBorder,
    error = EmergencyRed,
    onError = Color.White
)

@Composable
fun AanyaTheme(
    darkTheme: Boolean = true, // Default to futuristic dark theme
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
