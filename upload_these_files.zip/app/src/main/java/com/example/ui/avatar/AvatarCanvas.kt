package com.example.ui.avatar

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.theme.AvatarBlush
import com.example.ui.theme.AvatarEye
import com.example.ui.theme.AvatarEyeHighlight
import com.example.ui.theme.AvatarHair
import com.example.ui.theme.AvatarHairHighlight
import com.example.ui.theme.AvatarSkin
import com.example.ui.theme.AvatarSkinShadow
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPurple
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.sin

@Composable
fun AanyaAvatar(
    mood: AvatarMood,
    isSpeaking: Boolean,
    isListening: Boolean,
    modifier: Modifier = Modifier
) {
    // 1. Natural Breathing Transition (floating gently)
    val infiniteTransition = rememberInfiniteTransition(label = "avatar_infinite")
    val breathProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "breath"
    )
    val breathOffsetY = (sin(breathProgress) * 7f)
    val breathScale = 1f + (sin(breathProgress) * 0.015f)

    // 2. Headset Pulse Glow
    val glowPulse by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow_pulse"
    )

    // 3. Mouth Animation while Speaking
    val mouthAnim = remember { Animatable(0f) }
    LaunchedEffect(isSpeaking) {
        if (isSpeaking) {
            while (true) {
                mouthAnim.animateTo(0.85f, tween(110, easing = FastOutSlowInEasing))
                mouthAnim.animateTo(0.2f, tween(100, easing = FastOutSlowInEasing))
                mouthAnim.animateTo(1.0f, tween(140, easing = FastOutSlowInEasing))
                mouthAnim.animateTo(0.05f, tween(90, easing = FastOutSlowInEasing))
            }
        } else {
            mouthAnim.snapTo(0f)
        }
    }

    // 4. Natural Blinking Loop
    val blinkAnim = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        while (true) {
            delay((3000..5500).random().toLong())
            // First quick blink
            blinkAnim.animateTo(1f, tween(90, easing = FastOutSlowInEasing))
            blinkAnim.animateTo(0f, tween(110, easing = FastOutSlowInEasing))
            // 25% chance of charming double blink
            if ((1..4).random() == 1) {
                delay(120)
                blinkAnim.animateTo(1f, tween(80, easing = FastOutSlowInEasing))
                blinkAnim.animateTo(0f, tween(100, easing = FastOutSlowInEasing))
            }
        }
    }

    Box(
        modifier = modifier.testTag("aanya_avatar_canvas"),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val centerX = size.width / 2f
            val centerY = size.height / 2f + breathOffsetY
            val baseRadius = size.width.coerceAtMost(size.height) * 0.42f

            drawAvatar(
                cx = centerX,
                cy = centerY,
                radius = baseRadius * breathScale,
                mood = mood,
                isSpeaking = isSpeaking,
                isListening = isListening,
                blinkProgress = blinkAnim.value,
                mouthProgress = mouthAnim.value,
                glowAlpha = if (isListening) 1.0f else glowPulse
            )
        }
    }
}

private fun DrawScope.drawAvatar(
    cx: Float,
    cy: Float,
    radius: Float,
    mood: AvatarMood,
    isSpeaking: Boolean,
    isListening: Boolean,
    blinkProgress: Float,
    mouthProgress: Float,
    glowAlpha: Float
) {
    // --- 0. Cyber Neon Aura Ring behind Avatar ---
    val auraColor = when {
        isListening -> NeonCyan.copy(alpha = 0.35f * glowAlpha)
        isSpeaking -> NeonPurple.copy(alpha = 0.32f * glowAlpha)
        mood == AvatarMood.HAPPY -> Color(0xFFFFD54F).copy(alpha = 0.25f)
        mood == AvatarMood.CARING -> Color(0xFFF472B6).copy(alpha = 0.25f)
        else -> NeonCyan.copy(alpha = 0.18f * glowAlpha)
    }
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(auraColor, Color.Transparent),
            center = Offset(cx, cy),
            radius = radius * 1.55f
        ),
        radius = radius * 1.55f,
        center = Offset(cx, cy)
    )

    // --- 1. Back Hair (Deep Indigo with soft volume) ---
    val backHairPath = Path().apply {
        moveTo(cx - radius * 0.88f, cy + radius * 0.85f)
        cubicTo(
            cx - radius * 0.95f, cy - radius * 0.4f,
            cx - radius * 0.85f, cy - radius * 0.95f,
            cx, cy - radius * 0.95f
        )
        cubicTo(
            cx + radius * 0.85f, cy - radius * 0.95f,
            cx + radius * 0.95f, cy - radius * 0.4f,
            cx + radius * 0.88f, cy + radius * 0.85f
        )
        cubicTo(
            cx + radius * 0.5f, cy + radius * 0.72f,
            cx - radius * 0.5f, cy + radius * 0.72f,
            cx - radius * 0.88f, cy + radius * 0.85f
        )
        close()
    }
    drawPath(
        path = backHairPath,
        brush = Brush.verticalGradient(
            colors = listOf(AvatarHairHighlight, AvatarHair),
            startY = cy - radius,
            endY = cy + radius
        )
    )

    // --- 2. Headset Arc behind face ---
    val headsetArc = Path().apply {
        moveTo(cx - radius * 0.82f, cy - radius * 0.05f)
        cubicTo(
            cx - radius * 0.85f, cy - radius * 0.95f,
            cx + radius * 0.85f, cy - radius * 0.95f,
            cx + radius * 0.82f, cy - radius * 0.05f
        )
    }
    drawPath(
        path = headsetArc,
        color = Color(0xFF263252),
        style = Stroke(width = radius * 0.09f, cap = StrokeCap.Round)
    )
    drawPath(
        path = headsetArc,
        color = NeonCyan.copy(alpha = 0.8f * glowAlpha),
        style = Stroke(width = radius * 0.025f, cap = StrokeCap.Round)
    )

    // --- 3. Neck & Shoulders ---
    val neckWidth = radius * 0.28f
    val neckHeight = radius * 0.35f
    drawRoundRect(
        color = AvatarSkinShadow,
        topLeft = Offset(cx - neckWidth / 2f, cy + radius * 0.38f),
        size = Size(neckWidth, neckHeight),
        cornerRadius = CornerRadius(16f, 16f)
    )

    // Collar / Top with futuristic neon edge
    val collarPath = Path().apply {
        moveTo(cx - radius * 0.75f, cy + radius * 1.1f)
        lineTo(cx - neckWidth * 0.9f, cy + radius * 0.65f)
        quadraticTo(cx, cy + radius * 0.82f, cx + neckWidth * 0.9f, cy + radius * 0.65f)
        lineTo(cx + radius * 0.75f, cy + radius * 1.1f)
        close()
    }
    drawPath(
        path = collarPath,
        brush = Brush.verticalGradient(
            colors = listOf(Color(0xFF1E1B4B), Color(0xFF0F172A)),
            startY = cy + radius * 0.6f,
            endY = cy + radius * 1.1f
        )
    )
    // Neon collar line
    drawPath(
        path = Path().apply {
            moveTo(cx - neckWidth * 0.9f, cy + radius * 0.65f)
            quadraticTo(cx, cy + radius * 0.82f, cx + neckWidth * 0.9f, cy + radius * 0.65f)
        },
        color = NeonPurple,
        style = Stroke(width = radius * 0.03f, cap = StrokeCap.Round)
    )

    // --- 4. Face (Warm Anime Contour) ---
    val facePath = Path().apply {
        moveTo(cx - radius * 0.62f, cy - radius * 0.2f)
        cubicTo(
            cx - radius * 0.64f, cy + radius * 0.25f,
            cx - radius * 0.42f, cy + radius * 0.58f,
            cx, cy + radius * 0.68f // Cute rounded chin
        )
        cubicTo(
            cx + radius * 0.42f, cy + radius * 0.58f,
            cx + radius * 0.64f, cy + radius * 0.25f,
            cx + radius * 0.62f, cy - radius * 0.2f
        )
        cubicTo(
            cx + radius * 0.6f, cy - radius * 0.65f,
            cx - radius * 0.6f, cy - radius * 0.65f,
            cx - radius * 0.62f, cy - radius * 0.2f
        )
        close()
    }
    drawPath(
        path = facePath,
        brush = Brush.radialGradient(
            colors = listOf(AvatarSkin, AvatarSkinShadow),
            center = Offset(cx, cy),
            radius = radius * 0.8f
        )
    )

    // --- 5. Cute Soft Blush ---
    val blushRadius = radius * 0.12f
    val blushAlpha = if (mood == AvatarMood.HAPPY || mood == AvatarMood.CARING) 0.55f else 0.35f
    drawCircle(
        color = AvatarBlush.copy(alpha = blushAlpha),
        radius = blushRadius,
        center = Offset(cx - radius * 0.35f, cy + radius * 0.24f)
    )
    drawCircle(
        color = AvatarBlush.copy(alpha = blushAlpha),
        radius = blushRadius,
        center = Offset(cx + radius * 0.35f, cy + radius * 0.24f)
    )

    // --- 6. Cute Anime Eyes ---
    val eyeSpacing = radius * 0.28f
    val eyeCenterY = cy + radius * 0.08f
    val eyeWidth = radius * 0.19f
    val eyeHeight = radius * 0.24f

    drawAnimeEye(
        centerX = cx - eyeSpacing,
        centerY = eyeCenterY,
        width = eyeWidth,
        height = eyeHeight,
        mood = mood,
        blinkProgress = blinkProgress,
        isLeft = true
    )
    drawAnimeEye(
        centerX = cx + eyeSpacing,
        centerY = eyeCenterY,
        width = eyeWidth,
        height = eyeHeight,
        mood = mood,
        blinkProgress = blinkProgress,
        isLeft = false
    )

    // --- 7. Eyebrows (Dynamic Mood Reactions) ---
    drawMoodEyebrows(
        cx = cx,
        cy = eyeCenterY - eyeHeight * 0.75f,
        radius = radius,
        mood = mood
    )

    // --- 8. Cute Nose ---
    drawCircle(
        color = AvatarSkinShadow,
        radius = radius * 0.025f,
        center = Offset(cx, cy + radius * 0.26f)
    )

    // --- 9. Animated Mouth ---
    drawAnimatedMouth(
        cx = cx,
        cy = cy + radius * 0.42f,
        radius = radius,
        mood = mood,
        isSpeaking = isSpeaking,
        mouthProgress = mouthProgress
    )

    // --- 10. Front Hair & Cute Anime Bangs ---
    val bangsPath = Path().apply {
        moveTo(cx - radius * 0.65f, cy - radius * 0.2f)
        cubicTo(
            cx - radius * 0.5f, cy - radius * 0.5f,
            cx - radius * 0.2f, cy - radius * 0.15f,
            cx - radius * 0.18f, cy - radius * 0.02f // Left cute lock
        )
        quadraticTo(
            cx - radius * 0.1f, cy - radius * 0.28f,
            cx, cy - radius * 0.04f // Center soft curve
        )
        quadraticTo(
            cx + radius * 0.12f, cy - radius * 0.3f,
            cx + radius * 0.22f, cy - radius * 0.01f // Right cute lock
        )
        cubicTo(
            cx + radius * 0.45f, cy - radius * 0.2f,
            cx + radius * 0.65f, cy - radius * 0.45f,
            cx + radius * 0.65f, cy - radius * 0.2f
        )
        cubicTo(
            cx + radius * 0.7f, cy - radius * 0.85f,
            cx - radius * 0.7f, cy - radius * 0.85f,
            cx - radius * 0.65f, cy - radius * 0.2f
        )
        close()
    }
    drawPath(
        path = bangsPath,
        brush = Brush.verticalGradient(
            colors = listOf(AvatarHairHighlight, AvatarHair),
            startY = cy - radius * 0.8f,
            endY = cy
        )
    )

    // Front Side Locks (framing cheeks)
    val leftSideLock = Path().apply {
        moveTo(cx - radius * 0.62f, cy - radius * 0.15f)
        cubicTo(
            cx - radius * 0.68f, cy + radius * 0.2f,
            cx - radius * 0.55f, cy + radius * 0.5f,
            cx - radius * 0.52f, cy + radius * 0.55f
        )
        cubicTo(
            cx - radius * 0.46f, cy + radius * 0.45f,
            cx - radius * 0.52f, cy + radius * 0.15f,
            cx - radius * 0.5f, cy - radius * 0.1f
        )
        close()
    }
    drawPath(path = leftSideLock, color = AvatarHair)

    val rightSideLock = Path().apply {
        moveTo(cx + radius * 0.62f, cy - radius * 0.15f)
        cubicTo(
            cx + radius * 0.68f, cy + radius * 0.2f,
            cx + radius * 0.55f, cy + radius * 0.5f,
            cx + radius * 0.52f, cy + radius * 0.55f
        )
        cubicTo(
            cx + radius * 0.46f, cy + radius * 0.45f,
            cx + radius * 0.52f, cy + radius * 0.15f,
            cx + radius * 0.5f, cy - radius * 0.1f
        )
        close()
    }
    drawPath(path = rightSideLock, color = AvatarHair)

    // --- 11. Futuristic Cyber Headset Earcups with glowing LEDs ---
    drawCyberEarcup(
        cx = cx - radius * 0.72f,
        cy = cy - radius * 0.02f,
        radius = radius,
        isLeft = true,
        glowAlpha = glowAlpha,
        isListening = isListening
    )
    drawCyberEarcup(
        cx = cx + radius * 0.72f,
        cy = cy - radius * 0.02f,
        radius = radius,
        isLeft = false,
        glowAlpha = glowAlpha,
        isListening = isListening
    )

    // Hair Pin / Star Hologram on left side
    val pinCx = cx + radius * 0.42f
    val pinCy = cy - radius * 0.45f
    drawCircle(
        color = NeonCyan,
        radius = radius * 0.045f,
        center = Offset(pinCx, pinCy)
    )
    drawCircle(
        color = Color.White,
        radius = radius * 0.02f,
        center = Offset(pinCx, pinCy)
    )
}

private fun DrawScope.drawAnimeEye(
    centerX: Float,
    centerY: Float,
    width: Float,
    height: Float,
    mood: AvatarMood,
    blinkProgress: Float,
    isLeft: Boolean
) {
    if (mood == AvatarMood.HAPPY && blinkProgress < 0.4f) {
        // Joyful smiling eye arc (^_^)
        val archPath = Path().apply {
            moveTo(centerX - width * 0.9f, centerY + height * 0.15f)
            quadraticTo(centerX, centerY - height * 0.6f, centerX + width * 0.9f, centerY + height * 0.15f)
        }
        drawPath(
            path = archPath,
            color = AvatarEye,
            style = Stroke(width = width * 0.32f, cap = StrokeCap.Round)
        )
        return
    }

    // Normal anime eye with blinking interpolation
    val currentHeight = height * (1f - blinkProgress).coerceAtLeast(0.08f)
    if (blinkProgress > 0.85f) {
        // Closed eye line
        drawLine(
            color = AvatarEye,
            start = Offset(centerX - width * 0.8f, centerY),
            end = Offset(centerX + width * 0.8f, centerY),
            strokeWidth = width * 0.28f,
            cap = StrokeCap.Round
        )
        return
    }

    // Eye Sclera (White base)
    drawOval(
        color = Color.White,
        topLeft = Offset(centerX - width * 0.8f, centerY - currentHeight / 2f),
        size = Size(width * 1.6f, currentHeight)
    )

    // Iris (Deep violet to cyan gradient)
    val irisWidth = width * 1.15f
    val irisHeight = currentHeight * 0.95f
    val irisTopY = centerY - irisHeight / 2f
    drawOval(
        brush = Brush.verticalGradient(
            colors = listOf(AvatarEye, AvatarHair, NeonPurple),
            startY = irisTopY,
            endY = irisTopY + irisHeight
        ),
        topLeft = Offset(centerX - irisWidth / 2f, irisTopY),
        size = Size(irisWidth, irisHeight)
    )

    // Pupil
    drawCircle(
        color = Color(0xFF0F0B26),
        radius = irisWidth * 0.28f,
        center = Offset(centerX, centerY)
    )

    // Catchlight Highlights (Anime sparkle circles)
    val highlightRadius = irisWidth * 0.18f
    drawCircle(
        color = Color.White,
        radius = highlightRadius,
        center = Offset(centerX - irisWidth * 0.2f, centerY - currentHeight * 0.22f)
    )
    drawCircle(
        color = AvatarEyeHighlight,
        radius = highlightRadius * 0.55f,
        center = Offset(centerX + irisWidth * 0.22f, centerY + currentHeight * 0.18f)
    )

    // Upper Eyelash line
    val lashPath = Path().apply {
        moveTo(centerX - width * 0.9f, centerY - currentHeight * 0.42f)
        quadraticTo(
            centerX,
            centerY - currentHeight * 0.62f,
            centerX + width * 0.9f,
            centerY - currentHeight * 0.38f
        )
    }
    drawPath(
        path = lashPath,
        color = AvatarEye,
        style = Stroke(width = width * 0.22f, cap = StrokeCap.Round)
    )
}

private fun DrawScope.drawMoodEyebrows(
    cx: Float,
    cy: Float,
    radius: Float,
    mood: AvatarMood
) {
    val browWidth = radius * 0.18f
    val leftCenterX = cx - radius * 0.28f
    val rightCenterX = cx + radius * 0.28f

    val (leftYOffset, rightYOffset, tiltAngle) = when (mood) {
        AvatarMood.HAPPY -> Triple(-radius * 0.03f, -radius * 0.03f, 0.15f)
        AvatarMood.SAD -> Triple(radius * 0.02f, radius * 0.02f, -0.22f)
        AvatarMood.CARING -> Triple(-radius * 0.01f, -radius * 0.01f, -0.1f)
        AvatarMood.THINKING -> Triple(-radius * 0.04f, radius * 0.01f, 0.25f)
        AvatarMood.NEUTRAL -> Triple(0f, 0f, 0.05f)
    }

    // Left Eyebrow
    val leftBrow = Path().apply {
        moveTo(leftCenterX - browWidth / 2f, cy + leftYOffset + browWidth * tiltAngle)
        quadraticTo(
            leftCenterX,
            cy + leftYOffset - radius * 0.03f,
            leftCenterX + browWidth / 2f,
            cy + leftYOffset - browWidth * tiltAngle
        )
    }
    drawPath(
        path = leftBrow,
        color = AvatarHair,
        style = Stroke(width = radius * 0.028f, cap = StrokeCap.Round)
    )

    // Right Eyebrow
    val rightBrow = Path().apply {
        moveTo(rightCenterX - browWidth / 2f, cy + rightYOffset - browWidth * tiltAngle)
        quadraticTo(
            rightCenterX,
            cy + rightYOffset - radius * 0.03f,
            rightCenterX + browWidth / 2f,
            cy + rightYOffset + browWidth * tiltAngle
        )
    }
    drawPath(
        path = rightBrow,
        color = AvatarHair,
        style = Stroke(width = radius * 0.028f, cap = StrokeCap.Round)
    )
}

private fun DrawScope.drawAnimatedMouth(
    cx: Float,
    cy: Float,
    radius: Float,
    mood: AvatarMood,
    isSpeaking: Boolean,
    mouthProgress: Float
) {
    if (isSpeaking) {
        // Fluid talking mouth
        val mouthWidth = radius * (0.16f + mouthProgress * 0.12f)
        val mouthHeight = radius * (0.05f + mouthProgress * 0.16f)

        // Mouth cavity
        val mouthCavity = Path().apply {
            moveTo(cx - mouthWidth / 2f, cy)
            quadraticTo(cx, cy - mouthHeight * 0.3f, cx + mouthWidth / 2f, cy)
            quadraticTo(cx, cy + mouthHeight * 1.1f, cx - mouthWidth / 2f, cy)
            close()
        }
        drawPath(
            path = mouthCavity,
            color = Color(0xFF6B1D38),
            style = Fill
        )
        // Cute tongue tip
        if (mouthProgress > 0.4f) {
            drawCircle(
                color = Color(0xFFF472B6),
                radius = mouthHeight * 0.45f,
                center = Offset(cx, cy + mouthHeight * 0.45f)
            )
        }
        // Mouth outline
        drawPath(
            path = mouthCavity,
            color = Color(0xFF4C0519),
            style = Stroke(width = radius * 0.022f)
        )
        return
    }

    // Static mood mouth
    when (mood) {
        AvatarMood.HAPPY -> {
            // Sweet open smile
            val happyMouth = Path().apply {
                moveTo(cx - radius * 0.14f, cy)
                quadraticTo(cx, cy + radius * 0.14f, cx + radius * 0.14f, cy)
                quadraticTo(cx, cy + radius * 0.05f, cx - radius * 0.14f, cy)
                close()
            }
            drawPath(path = happyMouth, color = Color(0xFFBE185D))
            drawPath(
                path = Path().apply {
                    moveTo(cx - radius * 0.14f, cy)
                    quadraticTo(cx, cy + radius * 0.14f, cx + radius * 0.14f, cy)
                },
                color = Color(0xFF881337),
                style = Stroke(width = radius * 0.024f, cap = StrokeCap.Round)
            )
        }
        AvatarMood.CARING -> {
            // Warm gentle smile
            val caringSmile = Path().apply {
                moveTo(cx - radius * 0.12f, cy)
                quadraticTo(cx, cy + radius * 0.09f, cx + radius * 0.12f, cy)
            }
            drawPath(
                path = caringSmile,
                color = Color(0xFF9F1239),
                style = Stroke(width = radius * 0.025f, cap = StrokeCap.Round)
            )
        }
        AvatarMood.SAD -> {
            // Slight downward pout
            val sadMouth = Path().apply {
                moveTo(cx - radius * 0.09f, cy + radius * 0.05f)
                quadraticTo(cx, cy + radius * 0.01f, cx + radius * 0.09f, cy + radius * 0.05f)
            }
            drawPath(
                path = sadMouth,
                color = Color(0xFF9F1239),
                style = Stroke(width = radius * 0.025f, cap = StrokeCap.Round)
            )
        }
        else -> {
            // Neutral resting smile
            val neutralSmile = Path().apply {
                moveTo(cx - radius * 0.1f, cy + radius * 0.02f)
                quadraticTo(cx, cy + radius * 0.06f, cx + radius * 0.1f, cy + radius * 0.02f)
            }
            drawPath(
                path = neutralSmile,
                color = Color(0xFF9F1239),
                style = Stroke(width = radius * 0.022f, cap = StrokeCap.Round)
            )
        }
    }
}

private fun DrawScope.drawCyberEarcup(
    cx: Float,
    cy: Float,
    radius: Float,
    isLeft: Boolean,
    glowAlpha: Float,
    isListening: Boolean
) {
    val cupWidth = radius * 0.16f
    val cupHeight = radius * 0.32f

    // Outer earpad
    drawRoundRect(
        color = Color(0xFF1E293B),
        topLeft = Offset(cx - cupWidth / 2f, cy - cupHeight / 2f),
        size = Size(cupWidth, cupHeight),
        cornerRadius = CornerRadius(12f, 12f)
    )

    // Inner glowing LED panel
    val ledColor = if (isListening) NeonCyan else NeonPurple
    drawRoundRect(
        color = ledColor.copy(alpha = 0.9f * glowAlpha),
        topLeft = Offset(cx - cupWidth * 0.3f, cy - cupHeight * 0.35f),
        size = Size(cupWidth * 0.6f, cupHeight * 0.7f),
        cornerRadius = CornerRadius(8f, 8f)
    )

    // Glowing core bar
    drawLine(
        color = Color.White.copy(alpha = 0.85f * glowAlpha),
        start = Offset(cx, cy - cupHeight * 0.2f),
        end = Offset(cx, cy + cupHeight * 0.2f),
        strokeWidth = radius * 0.02f,
        cap = StrokeCap.Round
    )
}
