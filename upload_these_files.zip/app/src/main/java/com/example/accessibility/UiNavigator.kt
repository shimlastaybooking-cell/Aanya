package com.example.accessibility

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.view.accessibility.AccessibilityNodeInfo
import com.example.security.FinanceGuard

data class ScreenElement(
    val text: String,
    val contentDescription: String,
    val viewId: String,
    val className: String,
    val isClickable: Boolean,
    val isEditable: Boolean
)

class UiNavigator(private val service: AccessibilityService) {

    fun getRootNode(): AccessibilityNodeInfo? {
        return service.rootInActiveWindow
    }

    /**
     * Inspects current screen elements in a safe structured representation for LLM planner.
     */
    fun extractScreenElements(): List<ScreenElement> {
        val root = getRootNode() ?: return emptyList()

        // Immediate check: If any sensitive credentials (PIN, OTP, CVV, Password) exist, return empty to prevent reading
        if (FinanceGuard.hasSensitiveContent(root)) {
            return emptyList()
        }

        val list = mutableListOf<ScreenElement>()
        collectElements(root, list)
        return list
    }

    private fun collectElements(node: AccessibilityNodeInfo, list: MutableList<ScreenElement>) {
        val text = node.text?.toString()?.trim() ?: ""
        val desc = node.contentDescription?.toString()?.trim() ?: ""
        val viewId = node.viewIdResourceName?.substringAfterLast('/') ?: ""
        val className = node.className?.toString()?.substringAfterLast('.') ?: ""

        if (text.isNotBlank() || desc.isNotBlank() || node.isClickable || node.isEditable) {
            list.add(
                ScreenElement(
                    text = text,
                    contentDescription = desc,
                    viewId = viewId,
                    className = className,
                    isClickable = node.isClickable,
                    isEditable = node.isEditable
                )
            )
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collectElements(child, list)
        }
    }

    /**
     * Finds interactive node by text, content description, or view ID (semantic search, never coordinates).
     */
    fun findNode(target: String): AccessibilityNodeInfo? {
        val root = getRootNode() ?: return null
        if (FinanceGuard.hasSensitiveContent(root)) return null

        val targetLower = target.lowercase().trim()
        return searchNode(root, targetLower)
    }

    private fun searchNode(node: AccessibilityNodeInfo, target: String): AccessibilityNodeInfo? {
        val text = node.text?.toString()?.lowercase() ?: ""
        val desc = node.contentDescription?.toString()?.lowercase() ?: ""
        val viewId = node.viewIdResourceName?.lowercase() ?: ""

        if (text.contains(target) || desc.contains(target) || viewId.contains(target)) {
            // If the node itself is not clickable, check its ancestors up to 2 levels
            if (node.isClickable || node.isEditable) {
                return node
            }
            var parent = node.parent
            var depth = 0
            while (parent != null && depth < 3) {
                if (parent.isClickable) return parent
                parent = parent.parent
                depth++
            }
            return node
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = searchNode(child, target)
            if (found != null) return found
        }

        return null
    }

    fun click(target: String): Boolean {
        val node = findNode(target) ?: return false
        val clicked = node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        if (!clicked) {
            // Try parent
            node.parent?.let { parent ->
                return parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
        }
        return clicked
    }

    fun typeText(target: String, textToType: String): Boolean {
        val node = findNode(target) ?: return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, textToType)
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun scrollForward(): Boolean {
        val root = getRootNode() ?: return false
        return root.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
    }

    fun scrollBackward(): Boolean {
        val root = getRootNode() ?: return false
        return root.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
    }

    fun pressBack(): Boolean {
        return service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
    }

    fun pressHome(): Boolean {
        return service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
    }
}
