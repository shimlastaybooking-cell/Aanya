package com.example.accessibility

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import com.example.security.AuditLogger
import com.example.security.FinanceGuard
import com.example.security.KillSwitch

class AanyaAccessibilityService : AccessibilityService() {

    companion object {
        var instance: AanyaAccessibilityService? = null
            private set

        fun isConnected(): Boolean = instance != null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        AuditLogger.log(
            actionType = "ACCESSIBILITY_SERVICE",
            targetApp = "Android System",
            description = "Aanya Accessibility Service connected and ready for safe UI navigation",
            status = "SUCCESS"
        )
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        val pkgName = event.packageName?.toString()

        // 1. Instant check: Blocked Financial or Security Package
        if (FinanceGuard.isPackageBlocked(pkgName)) {
            AuditLogger.log(
                actionType = "SAFETY_BLOCK",
                targetApp = pkgName ?: "Unknown",
                description = "Blocked package detected in foreground. Phone control strictly suspended for this app.",
                status = "BLOCKED_SAFETY",
                isSafetyIntervention = true
            )
            return
        }

        // 2. Real-time sensitive UI check (PIN, OTP, CVV, Password)
        val root = rootInActiveWindow
        if (FinanceGuard.hasSensitiveContent(root)) {
            AuditLogger.log(
                actionType = "SENSITIVE_SCREEN_ABORT",
                targetApp = pkgName ?: "Active App",
                description = "Sensitive input screen detected (PIN/OTP/Password). UI observation halted.",
                status = "BLOCKED_SAFETY",
                isSafetyIntervention = true
            )
        }
    }

    override fun onInterrupt() {
        AuditLogger.log(
            actionType = "ACCESSIBILITY_SERVICE",
            targetApp = "Android System",
            description = "Aanya Accessibility Service interrupted",
            status = "INTERRUPTED"
        )
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }
}
