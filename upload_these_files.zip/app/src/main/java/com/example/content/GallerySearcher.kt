package com.example.content

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class GalleryItem(
    val id: Long,
    val uri: Uri,
    val displayName: String,
    val isVideo: Boolean,
    val isVertical9x16: Boolean,
    val width: Int,
    val height: Int,
    val dateAdded: Long
)

object GallerySearcher {

    suspend fun queryMedia(
        context: Context,
        onlyVertical9x16: Boolean = false,
        searchQuery: String = ""
    ): List<GalleryItem> = withContext(Dispatchers.IO) {
        val list = mutableListOf<GalleryItem>()
        val contentResolver = context.contentResolver

        // 1. Query Videos
        val videoProjection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.WIDTH,
            MediaStore.Video.Media.HEIGHT,
            MediaStore.Video.Media.DATE_ADDED
        )

        try {
            contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                videoProjection,
                null,
                null,
                "${MediaStore.Video.Media.DATE_ADDED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val wCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.WIDTH)
                val hCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.HEIGHT)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)

                var count = 0
                while (cursor.moveToNext() && count < 50) {
                    val id = cursor.getLong(idCol)
                    val name = cursor.getString(nameCol) ?: "Video_$id"
                    val w = cursor.getInt(wCol)
                    val h = cursor.getInt(hCol)
                    val date = cursor.getLong(dateCol)

                    // Check vertical 9:16 aspect ratio (ratio ~ 0.5625)
                    val isVertical = h > w && (h.toFloat() / w.coerceAtLeast(1).toFloat()) >= 1.6f
                    val uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)

                    if (searchQuery.isBlank() || name.contains(searchQuery, ignoreCase = true)) {
                        if (!onlyVertical9x16 || isVertical) {
                            list.add(GalleryItem(id, uri, name, true, isVertical, w, h, date))
                            count++
                        }
                    }
                }
            }
        } catch (_: Exception) {}

        // 2. Query Images
        val imageProjection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.WIDTH,
            MediaStore.Images.Media.HEIGHT,
            MediaStore.Images.Media.DATE_ADDED
        )

        try {
            contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                imageProjection,
                null,
                null,
                "${MediaStore.Images.Media.DATE_ADDED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                val wCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.WIDTH)
                val hCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.HEIGHT)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)

                var count = 0
                while (cursor.moveToNext() && count < 50) {
                    val id = cursor.getLong(idCol)
                    val name = cursor.getString(nameCol) ?: "Image_$id"
                    val w = cursor.getInt(wCol)
                    val h = cursor.getInt(hCol)
                    val date = cursor.getLong(dateCol)

                    val isVertical = h > w && (h.toFloat() / w.coerceAtLeast(1).toFloat()) >= 1.6f
                    val uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)

                    if (searchQuery.isBlank() || name.contains(searchQuery, ignoreCase = true)) {
                        if (!onlyVertical9x16 || isVertical) {
                            list.add(GalleryItem(id, uri, name, false, isVertical, w, h, date))
                            count++
                        }
                    }
                }
            }
        } catch (_: Exception) {}

        list.sortedByDescending { it.dateAdded }
    }
}
