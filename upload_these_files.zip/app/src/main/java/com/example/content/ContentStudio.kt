package com.example.content

import android.content.Context
import android.content.Intent
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class ContentIdea(
    val title: String,
    val hook: String,
    val caption: String,
    val hashtags: List<String>,
    val musicVibe: String
)

object ContentStudio {

    fun generateViralIdeas(category: String, topic: String): List<ContentIdea> {
        val cleanTopic = if (topic.isBlank()) "Daily Vibe" else topic
        return when (category.lowercase()) {
            "aesthetic / lifestyle" -> listOf(
                ContentIdea(
                    title = "Minimal Aesthetic Reel",
                    hook = "Yeh 3 cheezein meri daily peace ban gayi hain... ✨",
                    caption = "Slow mornings and intentional moments. Kabhi kabhi pause lena hi sabse badi growth hoti hai. Aapka favorite daily ritual kya hai? ☕🌿 #SlowLiving #AestheticVibes #PeacefulMind #DailyReset #MotoG85",
                    hashtags = listOf("#aesthetic", "#peace", "#lifestyle", "#mindfulness", "#dailymoments"),
                    musicVibe = "Lofi chilled beats / Ambient acoustic"
                ),
                ContentIdea(
                    title = "Quick Mood Shift",
                    hook = "5 minutes mein bad mood kaise fix karein? 🌸",
                    caption = "Jab sab kuch overwhelming lage na, tab yeh try karo: Ek warm glass paani, deep breath, aur 2 minute sunshine. Save this for rough days! 💖 #SelfCare #GoodVibesOnly #MentalWellness #MentalHealthMatters",
                    hashtags = listOf("#selfcare", "#mentalhealth", "#reelsindia", "#positivity", "#healing"),
                    musicVibe = "Soft indie pop acoustic"
                )
            )
            "tech & tips" -> listOf(
                ContentIdea(
                    title = "Moto G85 Secret Features",
                    hook = "Kya aapko apne Moto G85 ke yeh 3 hacks pata the? 📱",
                    caption = "120Hz pOLED display aur clean Android UX ko supercharge karo! Double chop for flashlight, peek display tricks, aur AI companion shortcuts! Comment karo aapka favorite Moto gesture! 🚀✨ #MotoG85 #AndroidTips #TechHacks #SmartPhoneLife",
                    hashtags = listOf("#techreels", "#androidtips", "#motog85", "#smartphonehacks", "#techindia"),
                    musicVibe = "Cyber upbeat synthwave"
                )
            )
            else -> listOf(
                ContentIdea(
                    title = "Relatable Friendship Moment",
                    hook = "Woh dost jisko bataye bina koi baat hazam nahi hoti! 😂",
                    caption = "Tag that one friend jo har baat pe 'Haan bhai bilkul!' bolta hai! Zindagi mein real dost hona sabse bada blessing hai. Cherish them! 💖✨ #Dosti #RelatableReel #FriendshipGoals #IndianMemes",
                    hashtags = listOf("#friendship", "#dosti", "#relatable", "#funnyreels", "#explorepage"),
                    musicVibe = "Fun upbeat Bollywood acoustic"
                ),
                ContentIdea(
                    title = "Daily Motivation Spark",
                    hook = "Rukna mat, thoda slow ho jao par rukna mat! 💫",
                    caption = "Progress is progress, no matter how small. Aaj ka ek chota step kal ki badi success banega. Believe in your journey! 🚀 #Motivation #HustleWithCare #DailyGrowth #Mindset",
                    hashtags = listOf("#motivation", "#mindset", "#growth", "#inspirational", "#reelsviral"),
                    musicVibe = "Cinematic building orchestra"
                )
            )
        }
    }

    /**
     * Prepares Instagram Reel share intent.
     * Note: Per safety rules, user confirmation must always occur before launching.
     */
    fun createInstagramShareIntent(videoUri: Uri?): Intent {
        return Intent(Intent.ACTION_SEND).apply {
            type = if (videoUri != null) "video/*" else "image/*"
            setPackage("com.instagram.android")
            if (videoUri != null) {
                putExtra(Intent.EXTRA_STREAM, videoUri)
            }
            putExtra("top_message", "Created with Aanya Companion on Moto G85")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }
}
