package com.example.security

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow

object KillSwitch {
    private val _isEmergencyStopped = MutableStateFlow(false)
    val isEmergencyStopped: StateFlow<Boolean> = _isEmergencyStopped.asStateFlow()

    private val _stopEvents = MutableSharedFlow<Unit>(extraBufferCapacity = 10)
    val stopEvents: SharedFlow<Unit> = _stopEvents.asSharedFlow()

    fun triggerEmergencyStop(source: String = "User Stop Button") {
        _isEmergencyStopped.value = true
        _stopEvents.tryEmit(Unit)
        AuditLogger.log(
            actionType = "KILL_SWITCH",
            targetApp = "ALL",
            description = "STOP ALL triggered via $source. Halting all phone tasks, TTS, and services.",
            status = "SUCCESS",
            isSafetyIntervention = true
        )
    }

    fun reset() {
        _isEmergencyStopped.value = false
    }
}
