package com.example.security

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class EncryptedStorage(context: Context) {

    private val prefs: SharedPreferences = try {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            "aanya_secure_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        // Fallback for testing environments / Robolectric / broken Keystore
        context.getSharedPreferences("aanya_secure_fallback_prefs", Context.MODE_PRIVATE)
    }

    fun getAnthropicApiKey(): String {
        return prefs.getString(KEY_ANTHROPIC_API_KEY, "") ?: ""
    }

    fun setAnthropicApiKey(key: String) {
        prefs.edit().putString(KEY_ANTHROPIC_API_KEY, key.trim()).apply()
    }

    fun getMetaGraphToken(): String {
        return prefs.getString(KEY_META_TOKEN, "") ?: ""
    }

    fun setMetaGraphToken(token: String) {
        prefs.edit().putString(KEY_META_TOKEN, token.trim()).apply()
    }

    fun isAppAllowed(packageName: String): Boolean {
        // Blocked packages are never allowed
        if (FinanceGuard.isPackageBlocked(packageName)) return false
        return prefs.getBoolean("app_perm_$packageName", true)
    }

    fun setAppAllowed(packageName: String, allowed: Boolean) {
        prefs.edit().putBoolean("app_perm_$packageName", allowed).apply()
    }

    companion object {
        private const val KEY_ANTHROPIC_API_KEY = "anthropic_api_key"
        private const val KEY_META_TOKEN = "meta_graph_token"
    }
}
