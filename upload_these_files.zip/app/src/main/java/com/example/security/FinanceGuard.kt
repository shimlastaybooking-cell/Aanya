package com.example.security

import android.view.accessibility.AccessibilityNodeInfo

object FinanceGuard {

    // Package-name blocklist: Banking, UPI, Wallets, Trading, Crypto, Settings, App Store, Password Managers
    private val BLOCKED_PACKAGES = setOf(
        // UPI & Payments (India & Global)
        "com.google.android.apps.nbu.paisa.user", // Google Pay
        "net.one97.paytm",                        // Paytm
        "com.phonepe.app",                        // PhonePe
        "in.org.npci.upiapp",                     // BHIM UPI
        "com.sbi.upi",                            // YONO SBI
        "com.icicibank.mobile",                   // iMobile Pay
        "com.hdfcbank.mobile",                    // HDFC Bank MobileBanking
        "com.axis.mobile",                        // Axis Mobile
        "com.kotak.bank",                         // Kotak 811
        "com.bankofbaroda.mconnect",              // bob World
        "com.pnb.pnbone",                         // PNB ONE
        "com.amazon.mShop.android.shopping.pay",  // Amazon Pay
        "com.paypal.android.p2pmobile",           // PayPal
        "com.freecharge.android",                 // Freecharge
        "com.mobikwik_new",                       // MobiKwik
        "com.cred.club",                          // CRED

        // Trading, Stock Brokers & Crypto
        "com.zerodha.kite3",                      // Kite by Zerodha
        "com.nextbillion.groww",                  // Groww
        "com.angelbroking.smartper",              // Angel One
        "com.upstox.pro",                         // Upstox
        "com.binance.dev",                        // Binance
        "com.coindcx",                            // CoinDCX
        "com.wazirx",                             // WazirX
        "com.coinbase.android",                   // Coinbase
        "com.kucoin.android",                     // KuCoin

        // Password Managers & Authenticators
        "com.x8bit.bitwarden",                    // Bitwarden
        "com.onepassword.android",                // 1Password
        "com.lastpass.lpandroid",                 // LastPass
        "com.dashlane",                           // Dashlane
        "com.nordpass.android",                   // NordPass
        "com.google.android.apps.authenticator2", // Google Authenticator
        "com.authy.authy",                        // Twilio Authy
        "com.azure.authenticator",                // Microsoft Authenticator

        // Critical System Settings & App Installers
        "com.android.settings",                   // Android Settings
        "com.google.android.packageinstaller",    // Package Installer
        "com.android.packageinstaller",           // AOSP Package Installer
        "com.google.android.vending"              // Google Play Store
    )

    // Keywords that indicate financial operations or commands
    private val BLOCKED_COMMAND_KEYWORDS = listOf(
        "transfer money", "send money", "paise bhej", "paise transfer",
        "upi pin", "bank balance", "cvv", "card number", "debit card",
        "credit card", "crypto", "buy bitcoin", "sell stock", "trade",
        "pay bill", "open gpay", "open phonepe", "open paytm", "open yono",
        "netbanking", "password btao", "otp btao", "read otp"
    )

    // Whole-word match so "pin" does not fire on "shopping", "pinned", "spinner" etc.
    private val SENSITIVE_TEXT_REGEX = Regex(
        "\\b(mpin|upi pin|pin|otp|one time password|cvv|card number|expiry date|password|" +
            "enter password|enter pin|passcode|secret code|security code)\\b",
        RegexOption.IGNORE_CASE
    )
    private val SENSITIVE_ID_REGEX = Regex("(^|[^a-z])(password|pin|mpin|otp|cvv)([^a-z]|$)")

    /** True if free text (notification, label, description) mentions a credential keyword. */
    fun containsSensitiveKeyword(text: String?): Boolean {
        if (text.isNullOrBlank()) return false
        return SENSITIVE_TEXT_REGEX.containsMatchIn(text)
    }

    fun isPackageBlocked(packageName: String?): Boolean {
        if (packageName.isNullOrBlank()) return false
        val lower = packageName.lowercase()
        return BLOCKED_PACKAGES.contains(lower) ||
                lower.contains("bank") ||
                lower.contains("wallet") ||
                lower.contains("trading") ||
                lower.contains("crypto") ||
                lower.contains("authenticator") ||
                lower.contains("bitwarden") ||
                lower.contains("1password")
    }

    fun isCommandRefused(commandText: String): Pair<Boolean, String?> {
        val lower = commandText.lowercase().trim()
        for (kw in BLOCKED_COMMAND_KEYWORDS) {
            if (lower.contains(kw)) {
                return Pair(
                    true,
                    "Aanya Security: Financial aur payment apps operate karna mere safety rules ke strict against hai. Main kabhi kisi financial app, UPI, OTP ya password ke saath interact nahi karti! 🛡️"
                )
            }
        }
        return Pair(false, null)
    }

    /**
     * Inspects accessibility node tree to detect any password input or sensitive credentials prompt.
     * Returns true if a sensitive element is found.
     */
    fun hasSensitiveContent(rootNode: AccessibilityNodeInfo?): Boolean {
        if (rootNode == null) return false
        return checkNodeRecursive(rootNode)
    }

    private fun checkNodeRecursive(node: AccessibilityNodeInfo): Boolean {
        // Direct password field check
        if (node.isPassword) {
            return true
        }

        // Check text content & content description (whole-word match)
        if (containsSensitiveKeyword(node.text?.toString())) return true
        if (containsSensitiveKeyword(node.contentDescription?.toString())) return true

        // Check view ID name (token match)
        val viewId = node.viewIdResourceName?.substringAfterLast('/')?.lowercase()
        if (viewId != null && SENSITIVE_ID_REGEX.containsMatchIn(viewId)) return true

        // Traverse children
        val count = node.childCount
        for (i in 0 until count) {
            val child = node.getChild(i) ?: continue
            if (checkNodeRecursive(child)) {
                return true
            }
        }
        return false
    }
}
