package com.example.security

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class AuditEntry(
    val id: Long = System.currentTimeMillis(),
    val timestamp: String = SimpleDateFormat("HH:mm:ss dd MMM", Locale.getDefault()).format(Date()),
    val actionType: String,
    val targetApp: String,
    val description: String,
    val status: String, // "SUCCESS", "BLOCKED_SAFETY", "CANCELLED", "REQUIRES_CONFIRMATION"
    val isSafetyIntervention: Boolean = false
)

object AuditLogger {
    private val _logs = MutableStateFlow<List<AuditEntry>>(
        listOf(
            AuditEntry(
                actionType = "INITIALIZE",
                targetApp = "Aanya Core",
                description = "Security guard and financial blocklist active",
                status = "SUCCESS"
            )
        )
    )
    val logs: StateFlow<List<AuditEntry>> = _logs.asStateFlow()

    fun log(
        actionType: String,
        targetApp: String,
        description: String,
        status: String = "SUCCESS",
        isSafetyIntervention: Boolean = false
    ) {
        val entry = AuditEntry(
            actionType = actionType,
            targetApp = targetApp,
            description = description,
            status = status,
            isSafetyIntervention = isSafetyIntervention
        )
        _logs.value = listOf(entry) + _logs.value.take(150)
    }

    fun clear() {
        _logs.value = emptyList()
    }
}
