package com.example.llm

import com.example.persona.AanyaPersonality
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class TaskActionJson(
    val action: String, // "click", "type", "scroll_forward", "scroll_backward", "back", "home", "open_app", "finish"
    val target: String = "",
    val text: String = "",
    val explanation: String = ""
)

class AnthropicClient {

    companion object {
        // Current Claude model id (the old claude-3-5-sonnet-20241022 has been retired).
        const val MODEL = "claude-sonnet-5-5"
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(35, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun sendChatMessage(
        apiKey: String,
        conversationHistory: List<Pair<String, String>>, // role, content
        userMessage: String
    ): Result<String> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            return@withContext Result.failure(IllegalStateException("Anthropic API Key is not set"))
        }

        try {
            val messagesArray = JSONArray()
            for ((role, content) in conversationHistory.takeLast(6)) {
                val msgObj = JSONObject()
                msgObj.put("role", if (role.lowercase() == "user") "user" else "assistant")
                msgObj.put("content", content)
                messagesArray.put(msgObj)
            }
            // Add current message
            val currentObj = JSONObject()
            currentObj.put("role", "user")
            currentObj.put("content", userMessage)
            messagesArray.put(currentObj)

            val payload = JSONObject().apply {
                put("model", MODEL)
                put("max_tokens", 600)
                put("system", AanyaPersonality.SYSTEM_PROMPT)
                put("messages", messagesArray)
            }

            val request = Request.Builder()
                .url("https://api.anthropic.com/v1/messages")
                .addHeader("x-api-key", apiKey)
                .addHeader("anthropic-version", "2023-06-01")
                .addHeader("content-type", "application/json")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()

            val response = client.newCall(request).execute()
            val bodyString = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("Anthropic API Error HTTP ${response.code}: $bodyString"))
            }

            val responseJson = JSONObject(bodyString)
            val contentArray = responseJson.optJSONArray("content")
            if (contentArray != null && contentArray.length() > 0) {
                val firstContent = contentArray.getJSONObject(0)
                val replyText = firstContent.optString("text", "")
                return@withContext Result.success(replyText)
            }

            Result.failure(Exception("Empty response received from Anthropic API"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun planNextPhoneAction(
        apiKey: String,
        goal: String,
        currentStep: Int,
        screenElementsSummary: String
    ): Result<TaskActionJson> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            return@withContext Result.failure(IllegalStateException("Anthropic API key required for LLM planner"))
        }

        try {
            val systemPrompt = """
You are an autonomous Android UI agent.
Goal: $goal
Step Number: $currentStep of 12.

Screen UI Elements currently visible:
$screenElementsSummary

Decide the ONE next action to accomplish the goal. Return ONLY raw JSON in this schema:
{
  "action": "click" | "type" | "scroll_forward" | "scroll_backward" | "back" | "home" | "open_app" | "finish",
  "target": "text/description of element or app to target",
  "text": "text to type if action is type, else empty",
  "explanation": "brief reason in Roman Hinglish"
}
SAFETY: Never touch PIN, passwords, OTPs, or financial apps.
""".trimIndent()

            val userObj = JSONObject().apply {
                put("role", "user")
                put("content", "What is the single next action to execute? Return valid JSON only.")
            }

            val payload = JSONObject().apply {
                put("model", MODEL)
                put("max_tokens", 300)
                put("system", systemPrompt)
                put("messages", JSONArray().put(userObj))
            }

            val request = Request.Builder()
                .url("https://api.anthropic.com/v1/messages")
                .addHeader("x-api-key", apiKey)
                .addHeader("anthropic-version", "2023-06-01")
                .addHeader("content-type", "application/json")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()

            val response = client.newCall(request).execute()
            val bodyString = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("LLM Planner API Error: ${response.code}"))
            }

            val responseJson = JSONObject(bodyString)
            val contentArray = responseJson.optJSONArray("content")
            val rawText = contentArray?.getJSONObject(0)?.optString("text", "") ?: ""

            // Extract JSON substring
            val jsonStart = rawText.indexOf('{')
            val jsonEnd = rawText.lastIndexOf('}')
            if (jsonStart != -1 && jsonEnd != -1) {
                val jsonStr = rawText.substring(jsonStart, jsonEnd + 1)
                val obj = JSONObject(jsonStr)
                val action = obj.optString("action", "finish")
                val target = obj.optString("target", "")
                val text = obj.optString("text", "")
                val explanation = obj.optString("explanation", "")
                return@withContext Result.success(TaskActionJson(action, target, text, explanation))
            }

            Result.failure(Exception("Could not parse JSON action from LLM response: $rawText"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
