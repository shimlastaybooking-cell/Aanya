package com.example.scheduler

import android.content.Context
import android.util.Log
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import java.util.concurrent.TimeUnit

object ScheduleManager {

    fun scheduleHydrationReminder(context: Context, enabled: Boolean) {
        try {
            val workManager = WorkManager.getInstance(context)
            val tag = "aanya_hydration_work"

            if (!enabled) {
                workManager.cancelUniqueWork(tag)
                return
            }

            val workRequest = PeriodicWorkRequestBuilder<ReminderWorker>(2, TimeUnit.HOURS)
                .setInputData(
                    workDataOf(
                        "title" to "Aanya: Hydration Time! 💧",
                        "message" to "Dost, ek glass paani pi lo! Stay fresh and energized! ✨"
                    )
                )
                .build()

            workManager.enqueueUniquePeriodicWork(
                tag,
                ExistingPeriodicWorkPolicy.UPDATE,
                workRequest
            )
        } catch (e: Exception) {
            Log.w("ScheduleManager", "WorkManager unavailable: ${e.message}")
        }
    }

    fun schedulePostureBreakReminder(context: Context, enabled: Boolean) {
        try {
            val workManager = WorkManager.getInstance(context)
            val tag = "aanya_posture_work"

            if (!enabled) {
                workManager.cancelUniqueWork(tag)
                return
            }

            val workRequest = PeriodicWorkRequestBuilder<ReminderWorker>(3, TimeUnit.HOURS)
                .setInputData(
                    workDataOf(
                        "title" to "Aanya: Screen Break & Stretch 🌿",
                        "message" to "Eyes ko rest do aur back straight karo! You are doing great! 🤗"
                    )
                )
                .build()

            workManager.enqueueUniquePeriodicWork(
                tag,
                ExistingPeriodicWorkPolicy.UPDATE,
                workRequest
            )
        } catch (e: Exception) {
            Log.w("ScheduleManager", "WorkManager unavailable: ${e.message}")
        }
    }

    fun scheduleSleepReminder(context: Context, enabled: Boolean) {
        try {
            val workManager = WorkManager.getInstance(context)
            val tag = "aanya_sleep_work"

            if (!enabled) {
                workManager.cancelUniqueWork(tag)
                return
            }

            val workRequest = PeriodicWorkRequestBuilder<ReminderWorker>(24, TimeUnit.HOURS)
                .setInputData(
                    workDataOf(
                        "title" to "Aanya: Good Night & Wind Down 🌙",
                        "message" to "Phone side rakhne ka time aa gaya hai! Rest well, kal milte hain. 😴✨"
                    )
                )
                .build()

            workManager.enqueueUniquePeriodicWork(
                tag,
                ExistingPeriodicWorkPolicy.UPDATE,
                workRequest
            )
        } catch (e: Exception) {
            Log.w("ScheduleManager", "WorkManager unavailable: ${e.message}")
        }
    }
}
