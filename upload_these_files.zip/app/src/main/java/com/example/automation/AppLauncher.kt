package com.example.automation

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import com.example.security.FinanceGuard

object AppLauncher {

    // Common app names mapped to standard package names
    private val KNOWN_APPS = mapOf(
        "instagram" to "com.instagram.android",
        "whatsapp" to "com.whatsapp",
        "youtube" to "com.google.android.youtube",
        "camera" to "com.motorola.camera3",
        "moto camera" to "com.motorola.camera3",
        "gallery" to "com.google.android.apps.photos",
        "photos" to "com.google.android.apps.photos",
        "chrome" to "com.android.chrome",
        "browser" to "com.android.chrome",
        "calculator" to "com.google.android.calculator",
        "clock" to "com.google.android.deskclock",
        "calendar" to "com.google.android.calendar",
        "notes" to "com.google.android.keep",
        "keep" to "com.google.android.keep",
        "maps" to "com.google.android.apps.maps",
        "spotify" to "com.spotify.music"
    )

    fun launchAppByName(context: Context, appName: String): Pair<Boolean, String> {
        val lower = appName.lowercase().trim()

        // 1. Blocklist check
        if (FinanceGuard.isPackageBlocked(lower)) {
            return Pair(false, "Safety Rule: Cannot open financial, banking or sensitive system apps.")
        }

        val pm: PackageManager = context.packageManager

        // Check if known app alias
        val mappedPackage = KNOWN_APPS[lower]
        if (mappedPackage != null) {
            if (FinanceGuard.isPackageBlocked(mappedPackage)) {
                return Pair(false, "Safety Rule: Blocked sensitive app.")
            }
            val intent = pm.getLaunchIntentForPackage(mappedPackage)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                return Pair(true, "Opened $appName successfully")
            }
        }

        // Try direct package launch
        val directIntent = pm.getLaunchIntentForPackage(appName)
        if (directIntent != null) {
            directIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(directIntent)
            return Pair(true, "Launched package: $appName")
        }

        // Search installed apps by label
        val installedApps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        for (app in installedApps) {
            val label = pm.getApplicationLabel(app).toString().lowercase()
            if (label.contains(lower)) {
                if (FinanceGuard.isPackageBlocked(app.packageName)) {
                    return Pair(false, "Safety Rule: $label is a financial/system restricted app.")
                }
                val launchIntent = pm.getLaunchIntentForPackage(app.packageName)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(launchIntent)
                    return Pair(true, "Opened $label")
                }
            }
        }

        return Pair(false, "App '$appName' not found on device.")
    }
}
