package com.example.automation

import android.content.Context
import com.example.accessibility.AanyaAccessibilityService
import com.example.accessibility.UiNavigator
import com.example.llm.AnthropicClient
import com.example.llm.TaskActionJson
import com.example.security.AuditLogger
import com.example.security.EncryptedStorage
import com.example.security.FinanceGuard
import com.example.security.KillSwitch
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class TaskStepInfo(
    val stepIndex: Int,
    val actionName: String,
    val target: String,
    val explanation: String,
    val status: String // "EXECUTING", "SUCCESS", "FAILED", "BLOCKED_SAFETY", "AWAITING_CONFIRMATION"
)

data class ActiveTaskState(
    val isRunning: Boolean = false,
    val goal: String = "",
    val currentStep: Int = 0,
    val maxSteps: Int = 12,
    val statusMessage: String = "",
    val stepsHistory: List<TaskStepInfo> = emptyList(),
    val awaitingConfirmationAction: TaskActionJson? = null
)

class PhoneTaskRunner(
    private val context: Context,
    private val encryptedStorage: EncryptedStorage,
    private val anthropicClient: AnthropicClient
) {
    private val _taskState = MutableStateFlow(ActiveTaskState())
    val taskState: StateFlow<ActiveTaskState> = _taskState.asStateFlow()

    suspend fun startPhoneTask(
        goal: String,
        onRequireConfirmation: (TaskActionJson, (Boolean) -> Unit) -> Unit
    ) {
        // 1. Initial Safety & Financial check on the goal string
        val (refused, refusalReason) = FinanceGuard.isCommandRefused(goal)
        if (refused) {
            AuditLogger.log(
                actionType = "COMMAND_REFUSED",
                targetApp = "ALL",
                description = refusalReason ?: "Financial command rejected",
                status = "BLOCKED_SAFETY",
                isSafetyIntervention = true
            )
            _taskState.value = ActiveTaskState(
                isRunning = false,
                goal = goal,
                statusMessage = refusalReason ?: "Command blocked by Safety Rules 🛡️"
            )
            return
        }

        // 2. Check if accessibility service is connected
        val service = AanyaAccessibilityService.instance
        if (service == null) {
            _taskState.value = ActiveTaskState(
                isRunning = false,
                goal = goal,
                statusMessage = "Accessibility Service is not enabled. Please enable Aanya in Android Accessibility Settings first."
            )
            return
        }

        KillSwitch.reset()
        AanyaForegroundService.start(context, "Executing Task: $goal")

        _taskState.value = ActiveTaskState(
            isRunning = true,
            goal = goal,
            currentStep = 0,
            statusMessage = "Starting phone task: '$goal'..."
        )

        AuditLogger.log(
            actionType = "TASK_START",
            targetApp = "System",
            description = "Started autonomous phone task: $goal",
            status = "SUCCESS"
        )

        val navigator = UiNavigator(service)
        val apiKey = encryptedStorage.getAnthropicApiKey()

        var step = 1
        val maxSteps = 12

        while (step <= maxSteps && !KillSwitch.isEmergencyStopped.value) {
            _taskState.value = _taskState.value.copy(
                currentStep = step,
                statusMessage = "Step $step/$maxSteps: Reading screen..."
            )

            // Step A: Inspect Screen & Verify Safety
            val root = navigator.getRootNode()
            if (root != null && FinanceGuard.hasSensitiveContent(root)) {
                val blockMsg = "Security Alert: Sensitive input (PIN/Password/OTP) detected! Halting task immediately."
                AuditLogger.log("SENSITIVE_SCREEN_HALT", "Active App", blockMsg, "BLOCKED_SAFETY", true)
                finishTask(false, blockMsg)
                return
            }

            val elements = navigator.extractScreenElements()
            val elementsSummary = if (elements.isEmpty()) {
                "No readable interactive elements or app is in background."
            } else {
                elements.take(20).joinToString("\n") {
                    "- [${it.className}] text=\"${it.text}\" desc=\"${it.contentDescription}\" id=\"${it.viewId}\" clickable=${it.isClickable}"
                }
            }

            // Step B: Plan next action (using Anthropic LLM or local fallback planner)
            val actionResult: TaskActionJson = if (apiKey.isNotBlank()) {
                val llmRes = anthropicClient.planNextPhoneAction(apiKey, goal, step, elementsSummary)
                if (llmRes.isSuccess) {
                    llmRes.getOrThrow()
                } else {
                    planLocalFallbackAction(goal, step, elements)
                }
            } else {
                planLocalFallbackAction(goal, step, elements)
            }

            // Step C: Check if action is finish
            if (actionResult.action.equals("finish", ignoreCase = true)) {
                recordStep(step, actionResult, "SUCCESS")
                finishTask(true, "Task completed successfully: ${actionResult.explanation}")
                return
            }

            // Step D: Destructive / Public actions require user confirmation dialog
            val isSensitiveAction = actionResult.action.equals("type", ignoreCase = true) &&
                    (actionResult.target.contains("send", ignoreCase = true) ||
                            actionResult.text.contains("delete", ignoreCase = true)) ||
                    actionResult.target.contains("post", ignoreCase = true) ||
                    actionResult.target.contains("share", ignoreCase = true) ||
                    actionResult.target.contains("delete", ignoreCase = true)

            if (isSensitiveAction) {
                var confirmedByUser = false
                var waitingForUser = true

                _taskState.value = _taskState.value.copy(
                    statusMessage = "User confirmation required for action: ${actionResult.action} on '${actionResult.target}'",
                    awaitingConfirmationAction = actionResult
                )

                onRequireConfirmation(actionResult) { confirmed ->
                    confirmedByUser = confirmed
                    waitingForUser = false
                }

                // Wait for confirmation
                while (waitingForUser && !KillSwitch.isEmergencyStopped.value) {
                    delay(300)
                }

                if (!confirmedByUser || KillSwitch.isEmergencyStopped.value) {
                    recordStep(step, actionResult, "CANCELLED")
                    finishTask(false, "Action cancelled by user or safety switch.")
                    return
                }
            }

            // Step E: Execute Action
            _taskState.value = _taskState.value.copy(
                statusMessage = "Step $step/$maxSteps: Executing ${actionResult.action}..."
            )

            val success = executeAction(context, navigator, actionResult)
            val statusStr = if (success) "SUCCESS" else "FAILED"
            recordStep(step, actionResult, statusStr)

            AuditLogger.log(
                actionType = "ACTION_${actionResult.action.uppercase()}",
                targetApp = actionResult.target,
                description = "${actionResult.explanation} (Success: $success)",
                status = statusStr
            )

            // Settle delay between steps for UI transitions
            delay(1400)
            step++
        }

        if (KillSwitch.isEmergencyStopped.value) {
            finishTask(false, "Task stopped via Emergency STOP ALL button.")
        } else {
            finishTask(true, "Reached maximum step limit (12 steps). Task completed.")
        }
    }

    private fun executeAction(
        context: Context,
        navigator: UiNavigator,
        action: TaskActionJson
    ): Boolean {
        return when (action.action.lowercase().trim()) {
            "open_app" -> {
                val (launched, _) = AppLauncher.launchAppByName(context, action.target)
                launched
            }
            "click" -> navigator.click(action.target)
            "type" -> navigator.typeText(action.target, action.text)
            "scroll_forward" -> navigator.scrollForward()
            "scroll_backward" -> navigator.scrollBackward()
            "back" -> navigator.pressBack()
            "home" -> navigator.pressHome()
            else -> false
        }
    }

    private fun planLocalFallbackAction(
        goal: String,
        step: Int,
        elements: List<com.example.accessibility.ScreenElement>
    ): TaskActionJson {
        val lowerGoal = goal.lowercase()

        // Rule: If step 1, usually open the requested app
        if (step == 1) {
            for (app in listOf("instagram", "whatsapp", "youtube", "calculator", "notes", "camera", "clock", "spotify")) {
                if (lowerGoal.contains(app)) {
                    return TaskActionJson(
                        action = "open_app",
                        target = app,
                        explanation = "Opening $app to begin task"
                    )
                }
            }
        }

        // Search for relevant buttons in current screen
        for (el in elements) {
            if (el.isClickable && (lowerGoal.contains(el.text.lowercase()) || lowerGoal.contains(el.contentDescription.lowercase()))) {
                val target = if (el.text.isNotBlank()) el.text else el.contentDescription
                return TaskActionJson(
                    action = "click",
                    target = target,
                    explanation = "Clicking matching element '$target'"
                )
            }
        }

        // Generic navigation
        return TaskActionJson(
            action = "finish",
            explanation = "Local planner completed step evaluation"
        )
    }

    private fun recordStep(stepIndex: Int, action: TaskActionJson, status: String) {
        val stepInfo = TaskStepInfo(
            stepIndex = stepIndex,
            actionName = action.action,
            target = action.target,
            explanation = action.explanation,
            status = status
        )
        _taskState.value = _taskState.value.copy(
            stepsHistory = _taskState.value.stepsHistory + stepInfo,
            awaitingConfirmationAction = null
        )
    }

    fun stopTask() {
        KillSwitch.triggerEmergencyStop("Task Runner Stop")
        finishTask(false, "Task manually stopped by user.")
    }

    private fun finishTask(success: Boolean, message: String) {
        _taskState.value = _taskState.value.copy(
            isRunning = false,
            statusMessage = message,
            awaitingConfirmationAction = null
        )
        AanyaForegroundService.stop(context)
    }
}
