package com.example.automation

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.security.KillSwitch

class AanyaForegroundService : Service() {

    companion object {
        const val CHANNEL_ID = "aanya_active_task_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START_TASK = "com.example.aanya.START_TASK"
        const val ACTION_STOP_TASK = "com.example.aanya.STOP_TASK"
        const val EXTRA_TASK_NAME = "extra_task_name"

        fun start(context: Context, taskName: String) {
            val intent = Intent(context, AanyaForegroundService::class.java).apply {
                action = ACTION_START_TASK
                putExtra(EXTRA_TASK_NAME, taskName)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, AanyaForegroundService::class.java).apply {
                action = ACTION_STOP_TASK
            }
            context.startService(intent)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_TASK) {
            KillSwitch.triggerEmergencyStop("Foreground Notification STOP Action")
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        val taskName = intent?.getStringExtra(EXTRA_TASK_NAME) ?: "Aanya Assistant Active"
        val notification = buildNotification(taskName)
        startForeground(NOTIFICATION_ID, notification)

        return START_STICKY
    }

    private fun buildNotification(taskName: String): Notification {
        // Tap to open app
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Emergency STOP Action button
        val stopIntent = Intent(this, AanyaForegroundService::class.java).apply {
            action = ACTION_STOP_TASK
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Aanya AI is Active 🛡️")
            .setContentText(taskName)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .setContentIntent(openPendingIntent)
            .addAction(
                android.R.drawable.ic_delete,
                "STOP ALL",
                stopPendingIntent
            )
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Aanya Active Tasks",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Shows notifications when Aanya is assisting with tasks"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }
}
