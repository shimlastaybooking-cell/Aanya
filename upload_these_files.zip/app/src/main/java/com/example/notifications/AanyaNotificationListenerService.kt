package com.example.notifications

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.example.security.FinanceGuard
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class NotificationSummary(
    val id: String,
    val appPackage: String,
    val title: String,
    val snippet: String,
    val timestamp: Long = System.currentTimeMillis()
)

class AanyaNotificationListenerService : NotificationListenerService() {

    companion object {
        private val _recentSummaries = MutableStateFlow<List<NotificationSummary>>(emptyList())
        val recentSummaries: StateFlow<List<NotificationSummary>> = _recentSummaries.asStateFlow()

        var isConnected: Boolean = false
            private set
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        isConnected = true
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        isConnected = false
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        val pkg = sbn.packageName ?: return

        // 1. Strict Privacy & Financial Safety Guard: Ignore banking & payment notifications completely!
        if (FinanceGuard.isPackageBlocked(pkg)) return

        val extras = sbn.notification.extras ?: return
        val title = extras.getString("android.title") ?: ""
        val text = extras.getCharSequence("android.text")?.toString() ?: ""

        // 2. Strict Filter: Never read or store OTP, PIN, verification codes or passwords
        val lowerText = "$title $text".lowercase()
        if (FinanceGuard.containsSensitiveKeyword(lowerText) ||
            lowerText.contains("verification code") ||
            lowerText.contains("bank")
        ) {
            return
        }

        if (title.isNotBlank() || text.isNotBlank()) {
            val summary = NotificationSummary(
                id = "${sbn.id}_${sbn.postTime}",
                appPackage = pkg,
                title = title,
                snippet = text.take(120)
            )
            _recentSummaries.value = (listOf(summary) + _recentSummaries.value).take(25)
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {}
}
